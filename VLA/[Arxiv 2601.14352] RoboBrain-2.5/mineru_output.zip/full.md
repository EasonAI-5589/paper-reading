# RoboBrain 2.5: Depth in Sight, Time in Mind.

# BAAI RoboBrain Team

Please see Contributions and Author List for more author details.

# Abstract

We introduce RoboBrain 2.5, a next-generation embodied AI foundation model that advances general perception, spatial reasoning, and temporal modeling through extensive training on high-quality spatiotemporal supervision. Building upon its predecessor, RoboBrain 2.5 introduces two major capability upgrades. Specifically, it unlocks Precise 3D Spatial Reasoning by shifting from 2D pixel-relative grounding to depth-aware coordinate prediction and absolute metric constraint comprehension, generating complete 3D manipulation traces as ordered keypoint sequences under physical constraints. Complementing this spatial precision, the model establishes Dense Temporal Value Estimation that provides dense, step-aware progress prediction and execution state understanding across varying viewpoints, producing stable feedback signals for downstream learning. Together, these upgrades extend the framework toward more physically grounded and execution-aware embodied intelligence for complex, fine-grained manipulation. The code and checkpoints are available at project website: https://superrobobrain.github.io.

![](images/094e51b45b9b729e46f618def443ee41034276c4734dee8a591b78879e7c850a.jpg)  
Figure 1 New Features of RoboBrain 2.5. Top: Precise 3D spatial reasoning with depth-aware grounding, metric measuring, and full manipulation trace generation under physical constraints. Bottom: Dense temporal value estimation for step-aware progress/regress prediction from state transitions across viewpoints and tasks; radar plots summarize performance gains on 2D/3D spatial and temporal benchmarks.

# Contents

# 1 Introduction 3

# 2 New Feature 4

2.1 Precise 3D Spatial Reasoning 4   
2.1.1 3D Spatial Referring, Measuring, and Tracing 4   
2.1.2 3D Task Formulation . . 4   
2.2 Dense Temporal Value Estimation 5   
2.2.1 Hop-wise Progress Construction 5   
2.2.2 Multi-Perspective Progress Fusion 6   
2.2.3 Bi-directional Consistency Checking 6

# 3 Training Data 7

3.1 General MLLM Data . . 7   
3.2 Spatial Reasoning Data 8   
3.3 Temporal Prediction Data 10

# 4 Training Strategy 11

4.1 Stage 1: Foundational Spatiotemporal Learning 11   
4.2 Stage 2: Specific Spatiotemporal Enhancement 12

# 5 Infrastructure 12

5.1 Hybrid Parallelism 1 2   
5.2 Dynamic pre-Allocated Memory . 13   
5.3 Cross-Accelerator Training and Inference 1 3

# 6 Evaluation Results 13

6.1 2D Spatial Reasoning Capability 14   
6.2 3D Spatial Reasoning Capability 15   
6.3 Temporal Value Estimation 16

# 7 Conclusion and Future Works 17

8 Contributions and Author List 23

# Qualitative examples 24

A.1 Examples on 3D Spatial Reasoning 24   
A.2 Examples on Temporal Value Estimation 32

B Proof of Bounded Global Progress 37

# 1 Introduction

Embodied AI foundation models have rapidly advanced in bridging language, vision, and action, enabling the generation of actionable plans from natural language instructions and visual observations [7, 32, 73]. However, a critical gap persists. While these models often succeed in curated demonstrations, they frequently falter during rigorous real-world deployments. This reliability issue stems from the challenge of translating high-level semantic reasoning into physically grounded manipulation. Real-world tasks are unforgiving. They demand that robots respect absolute metric constraints, operate robustly under occlusions and viewpoint shifts, and continuously self-correct in a closed loop. Unfortunately, these precise physical capabilities remain beyond the reach of current semantic planners.

These requirements expose two fundamental limitations in current generalist models. First, on the spatial dimension, models suffer from “metric blindness.” Grounding is typically restricted to 2D pixel coordinates or weak topological representations [9, 13, 85]. Lacking absolute depth and scale information, such outputs inherently fail to ensure physical compliance. Specifically, they cannot guarantee millimeter-level clearance or generate collision-free 3D trajectories which are critical for precise interaction. Second, on the temporal dimension, models usually operate as “open-loop” predictors. They treat action generation as a static sequence prediction task without an intrinsic mechanism to monitor execution progress. Relying on sparse external supervision such as success labels [2, 53], the agent remains oblivious to intermediate failures like slippage or regression. This limitation makes adaptive recovery impossible in long-horizon tasks.

To bridge this gap, embodied foundation models must undergo a paradigm shift from semantic reasoners to physically-grounded agents. This evolution requires two precise upgrades. Spatial reasoning must advance from 2D pointing to precise 3D planning to satisfy metric constraints. Simultaneously, temporal modeling must shift from open-loop generation to dense value estimation to ensure closed-loop reliability.

To realize this vision, we present RoboBrain 2.5. Building upon the robust general perception and reasoning capabilities of its predecessor [33, 72], this next-generation model introduces critical upgrades to align internal representations with physical reality. Through large-scale training on high-quality spatiotemporal data, RoboBrain 2.5 achieves a comprehensive upgrade in core capabilities:

• Spatial: Depth in Sight (Precise 3D Spatial Reasoning). We extend the spatial interface from 2D grounding to depth-aware coordinate prediction and full manipulation trace generation. Instead of predicting a single target point, the model learns to output an ordered sequence of keypoints that describes the complete manipulation procedure, thereby naturally encoding spatial planning. This capability is built via a curriculum of three complementary skills: (1) 3D Spatial Referring to localize objects; (2) $3 D$ Spatial Measuring to estimate absolute metric quantities (e.g., distance, clearance) required by physical constraints; and (3) 3D Spatial Trace Generation to produce collision-free keypoint traces. Crucially, this is achieved by standardizing supervision into a decoupled $( u , v , d )$ representation convertible to 3D via camera intrinsics, leveraging large-scale, high-quality 3D supervision across diverse scenes.

• Temporal: Time in Mind (Dense Temporal Value Estimation). In parallel, we establish a breakthrough in temporal modeling that provides immediate, step-aware feedback robust to viewpoint variations. The objective is to estimate the execution state (progress, stagnation, regression, or error) using only visual observations. We implement this by modeling general reward on multi-view expert trajectories using hop-normalized temporal transition labels. This formulation normalizes progress by the remaining distance to the goal, producing bounded and stable supervision signals even with dense sampling. Furthermore, we employ multi-perspective fusion to aggregate value predictions, significantly improving robustness under occlusion. Consequently, RoboBrain 2.5 provides dense progress tracking that serves as a high-fidelity reward signal for downstream reinforcement learning.

• Synergy and Impact. Crucially, RoboBrain 2.5 integrates these physical capabilities without sacrificing the general interactive reasoning of the original architecture. By imparting “Depth in Sight” to ensure kinematic feasibility and “Time in Mind” to ensure execution robustness, our model successfully bridges the reliability gap. Extensive experiments on serious benchmarks demonstrate state-of-the-art performance. Furthermore, real-world evaluations confirm superior zero-shot robustness in contact-rich tasks, effectively translating demo-level success into deployment-level reliability.

# 2 New Feature

Building upon the foundation of RoboBrain 2.0 [72] and utilizing the Qwen3-VL architecture [8], RoboBrain 2.5 introduces two core enhancements that further advance physical intelligence. Specifically, we first detail the concept of Precise 3D Spatial Reasoning (Section 2.1), which encompasses three metric-grounded competencies,- spatial referring, measuring, and tracing—derived solely from monocular RGB inputs [86]. We then describe Dense Temporal Value Estimation(Section 2.2), which learns a general-purpose, step-aware process modeling from multi-view RGB-only observations [67].

# 2.1 Precise 3D Spatial Reasoning

For embodied agents to interact effectively with the physical world, they must accurately interpret and act upon spatial information. This necessitates a deep understanding of object locations, inter-object relationships, and precise metric quantities from visual observations. To address these fundamental requirements, we introduce a robust framework for Precise 3D Spatial Reasoning.

# 2.1.1 3D Spatial Referring, Measuring, and Tracing

Embodied robots usually have to execute actions based on increasingly complex, spatially constrained instructions [1, 10, 11, 34, 68, 70, 71, 85], such as “Water flowers from left to right with watering can hovering $_ { 1 - 5 }$ cm above each one” in Figure 1, where recent data-scarce Vision-Language-Action (VLA) models fail to master. In this case, it would be beneficial to generate a 3D positional sequence, named as 3D spatial trace, as an intuitive bridge to interpret the instruction following procedure in 3D space and guide the generation of actual action trajectories for robots. However, this surrogate task (i.e., 3D spatial tracing) is inherently challenging as it requires multi-step, metric-grounded reasoning in complex 3D scenes. To be specific, each reasoning step requires two key components: (1) 3D spatial referring to resolve spatial relationships and accurately localize objects involved in the trace generation (e.g., identifying flowers with their from left to right order and locating them). (2) 3D spatial measuring to understand absolute, real-world metric quantities related to the trace in captured scene (e.g., quantifying each flower’s physical height and 1–5 cm height above each). To this end, we equip RoboBrain 2.5 with these three key capabilities, enabling it to directly predict metric-grounded outputs from monocular images under spatial constraints for direct interaction with the 3D physical world.

# 2.1.2 3D Task Formulation

We formalize 3D spatial tracing as the process of predicting an ordered sequence of 3D points $\tau = \{ p _ { t } \} _ { t = 1 } ^ { T }$ —each point $p _ { t } = ( u _ { t } , v _ { t } , d _ { t } )$ comprising image-plane coordinates $( u _ { t } , v _ { t } )$ and absolute depth $d _ { t }$ —from visual inputs (e.g., RGB images) and textual instructions via vision-language models. The resulting trace $\tau$ functions as a spatial plan for guiding entities (e.g., a robot end-effector or an object) to execute instructions. Crucially, these instructions typically encode both 3D spatial referring and 3D spatial measuring, often requiring multi-step compositional reasoning. For instance, in Figure 1, the instruction “Water flowers from left to right with watering can hovering 1-5 cm above each flower ” necessitates determining the 3D positions and heights of all flowers in the scene. Although intermediate spatial cues (e.g., points identified through 3D spatial referring) may not coincide with the final keypoints used in the spatial trace, they provide essential evidence for multi-step reasoning—thereby enabling precise trace generation under spatial constraints at the start, the end, and along the trajectory. At the core of our approach lies a task formulation designed to facilitate training and to leverage diverse data sources effectively. Rather than predicting 3D coordinates in the form $( x , y , z )$ in camera or world frame, we adopt a decoupled $( u , v , d )$ representation, which can be trivially projected to 3D coordinates using known camera intrinsics. This formulation is especially advantageous in embodied scenarios where camera parameters are readily accessible, as it obviates the need for vision-language models to learn camera geometry implicitly. Such an approach streamlines training and enhances accuracy. Furthermore, the $( u , v , d )$ representation can be straightforwardly projected into lower-dimensional subspaces. For instance, omitting $d$ yields a 2D visual trace (i.e., a sequence of points in the image plane), while retaining only the start and end points produces 3D or 2D spatial referring data (if depth is further removed). This flexibility not only promotes data reusability but also ensures compatibility with existing 2D datasets [23, 85], thereby boosting multi-task learning performance through co-training across complementary tasks and modalities.

# 2.2 Dense Temporal Value Estimation

Effective execution of long-horizon manipulation tasks demands more than just a final success signal; it requires continuous, granular feedback to guide the agent through complex intermediate states [3, 15, 52, 54, 80]. To address the limitations of sparse feedback, we introduce Dense Temporal Value Estimation, a vision-based mechanism that provides real-time, step-aware progress assessments as temporal value feedback, enabling robust closed-loop control and efficient RL.

# 2.2.1 Hop-wise Progress Construction

Central to our approach is the formulation of value estimation as task progress; thus, our model functions as a vision-language estimator designed to infer fine-grained, real-time progress from visual inputs. To guarantee generalizability across diverse embodiments and task families, we implement a three-stage data curation pipeline handling diverse data origins. This process spans from raw video segmentation to a systematic, hop-based labeling strategy, as detailed below:

Step-wise task progress discretization. Given raw multi-view video trajectories, we first segment each expert trajectory into sub-tasks using human-annotated multi-view keyframes $\{ K _ { 0 } , K _ { 1 } , \ldots , K _ { N } \}$ , where $K _ { 0 }$ is the initial observation, $K _ { N }$ is the final success observation, and each $K _ { j }$ is a set of synchronized multi-view keyframes. To obtain dense supervision, we perform adaptive sampling within each segment. For a trajectory with $L$ frames per view, we set a chunk size $C$ to determine the total number of sampled points and distribute them uniformly across the $N$ segments. The number of intermediate points $m$ within segment $[ K _ { j } , K _ { j + 1 } ]$ is:

$$
m = \left\lfloor { \frac { 1 } { N } } \left\lfloor { \frac { L } { C } } \right\rfloor \right\rfloor .
$$

This yields a sequence of states $\mathcal { S } = \{ s _ { 0 } , s _ { 1 } , . . . , s _ { M } \}$ , where each state $s _ { i }$ is a set of synchronous multi-view visual observations. We then define the ground-truth global progress as $\Phi ( s _ { i } ) = i / M$ .

Hop-based relative progress normalization. A naive choice is to regress the progress gain $\Phi _ { \delta } ( s _ { p } , s _ { q } ) =$ $\Phi ( s _ { q } ) - \Phi ( s _ { p } )$ between two states, but iterating such predictions accumulates error and can push the reconstructed $\Phi ^ { \star } ( s )$ outside $[ 0 , 1 ]$ . Instead, we introduce a hop-based formulation that learns relative-relative progress and naturally supports dense temporal value estimation. Each training sample is a tuple $\mathcal { D }$ containing a task description $d _ { \mathrm { t a s k } }$ , the initial state $s _ { 0 }$ , the goal state $s _ { M }$ , a “ $B E F O R E ^ { \prime \prime }$ state $s _ { p }$ , an “AFTER” state $s _ { q }$ and a hop label $\mathcal { H } ( s _ { p } , s _ { q } )$ that normalizes the progress from $s _ { p }$ to $s _ { q }$ relative to the full task span from $s _ { 0 }$ to $s _ { M }$ . Given $\Phi ( s _ { p } )$ and $\Phi ( s _ { q } )$ , we define:

$$
\begin{array} { r } { \mathcal { H } ( s _ { p } , s _ { q } ) = \left\{ \begin{array} { l l } { \frac { \Phi ( s _ { q } ) - \Phi ( s _ { p } ) } { \Phi \left( s _ { M } \right) - \Phi ( s _ { p } ) } } & { \mathrm { i f ~ } q \geq p \mathrm { ~ ( P R O G R E S S ) ~ } } \\ { \quad } \\ { \frac { \Phi ( s _ { q } ) - \Phi ( s _ { p } ) } { \Phi ( s _ { p } ) - \Phi ( s _ { 0 } ) } } & { \mathrm { i f ~ } q < p \mathrm { ~ ( R E G R E S S ) . } } \end{array} \right. } \end{array}
$$

This dynamically scales the supervision into $[ - 1 , 1 ]$ : for forward progress, the change is normalized by the remaining distance to the goal; for regression, by the distance already covered from the initial state. A key theoretical advantage is that, when global progress is reconstructed by iteratively applying predicted hops, the resulting $\Phi ^ { \star } ( s )$ is guaranteed to remain strictly within $[ 0 , 1 ]$ . Please refer to Section B for the proof.

Sampling strategy and data balancing. For each trajectory, we construct a balanced set of hop-based training samples. Continuous hop values are first discretized into $N _ { \mathrm { h o p } }$ hop bins. The temporal distance between the “BEFORE” state $s _ { p }$ and “AFTER” state $s _ { q }$ in each pair is then chosen from $N _ { \mathrm { d i s } }$ distance bins within each hop bin, yielding in total $N _ { \mathrm { h o p } } \times N _ { \mathrm { d i s } }$ non-trivial transitions. To reduce bias toward static segments, we further introduce an additional fraction $\alpha$ of samples explicitly labeled as zero-hop (i.e., $\mathcal { H } ( s _ { p } , s _ { q } ) = 0$ ), constructed by selecting pairs $( s _ { p } , s _ { q } )$ whose progress change is below a small threshold $\epsilon$ :

$$
| \Phi ( s _ { q } ) - \Phi ( s _ { p } ) | \leq \epsilon .
$$

# 2.2.2 Multi-Perspective Progress Fusion

To mitigate error accumulation and ensure consistent accuracy, we fuse dense temporal value estimates from three complementary perspectives: incremental prediction, forward-anchored prediction, and backwardanchored prediction.

Incremental Prediction offers a fine-grained, step-by-step assessment. Refer to Equation (2), the predicted global progress $\Phi _ { I } ^ { \star } ( s _ { t } )$ is recursively computed from the preceding state’s progress $\Phi ^ { \star } \left( s _ { t - 1 } \right)$ and the predicted hop $\mathcal { H } ^ { \star } ( s _ { t - 1 } , s _ { t } )$ . Let $\Delta \Phi _ { t - 1 , t } ^ { \star }$ be the estimated progress hop:

$$
\Delta \Phi _ { t - 1 , t } ^ { \star } = \left\{ \begin{array} { l l } { \left[ 1 - \Phi ^ { \star } ( s _ { t - 1 } ) \right] \cdot \mathcal { H } ^ { \star } } & { \mathrm { i f ~ } \mathcal { H } ^ { \star } \geq 0 } \\ { \Phi ^ { \star } ( s _ { t - 1 } ) \cdot \mathcal { H } ^ { \star } } & { \mathrm { i f ~ } \mathcal { H } ^ { \star } < 0 . } \end{array} \right.
$$

The incremental progress is then calculated as follow:

$$
\begin{array} { r } { \Phi _ { I } ^ { \star } ( s _ { t } ) = \Phi ^ { \star } ( s _ { t - 1 } ) + \Delta \Phi _ { t - 1 , t } ^ { \star } , } \end{array}
$$

where $\Phi _ { I } ^ { \star } ( s _ { t } )$ is accumulated along the trajectory, initialized with $\Phi ^ { \star } ( s _ { 0 } ) = 0$ . While this method excels at capturing local dynamics, it is susceptible to the accumulation of prediction errors over long trajectories. To counteract this drift, we introduce two global perspectives. Forward-Anchored Prediction provides a stable global reference by anchoring to the initial state $s _ { \mathrm { i n i t } }$ , where progress is zero:

$$
\Phi _ { F } ^ { \star } ( s _ { t } ) = \mathcal { H } ^ { \star } ( s _ { \mathrm { i n i t } } , s _ { t } ) .
$$

Conversely, Backward-Anchored Prediction is anchored to the goal state $s _ { \mathrm { g o a l } }$ , where progress is one. This approach offers high sensitivity near task completion:

$$
\begin{array} { r } { \Phi _ { B } ^ { \star } ( s _ { t } ) = 1 + \mathcal H ^ { \star } ( s _ { \mathrm { g o a l } } , s _ { t } ) . } \end{array}
$$

These three methods offer complementary strengths: local precision (incremental), initial stability (forward), and goal sensitivity (backward). We fuse them via averaging to obtain a robust final progress estimate:

$$
\Phi ^ { \star } ( s _ { t } ) = \frac { 1 } { 3 } \left( \Phi _ { I } ^ { \star } ( s _ { t } ) + \Phi _ { F } ^ { \star } ( s _ { t } ) + \Phi _ { B } ^ { \star } ( s _ { t } ) \right) .
$$

This fusion yields a more accurate and drift-resistant value signal. Please also refer to [67] for how to apply this kind of value signal for RL process.

# 2.2.3 Bi-directional Consistency Checking

While the multi-perspective fusion via averaging (Equation (8)) serves as a baseline, its naive application in online RL faces the risk of Out-of-Distribution (OOD) hallucination. Due to the inherent limitations of data coverage, it is impossible for the training set to encompass every corner of the state space. During RL, the policy inevitably explores unseen regions where dense temporal value estimation may yield spurious high signals, leading to “reward hacking.” To address these, we propose a bi-directional consistency checking strategy that leverages consistency as a proxy for reliability. This design is motivated by the observation that forward $\Phi _ { F } ^ { * }$ and backward $\Phi _ { B } ^ { * }$ predictions tend to diverge significantly under OOD observations, whereas they remain consistent in familiar states.

Consistency-Aware Weighting. We first define the mean estimated progress $\Phi ^ { * } ( s _ { t } ) = ( \Phi _ { F } ^ { * } ( s _ { t } ) + \Phi _ { B } ^ { * } ( s _ { t } ) ) / 2$ To quantify uncertainty, we calculate a normalized discrepancy metric:

$$
\Delta _ { \mathrm { n o r m } } ( s _ { t } ) = \frac { \vert \Phi _ { B } ^ { \ast } ( s _ { t } ) - \Phi _ { F } ^ { \ast } ( s _ { t } ) \vert } { \bar { \Phi } ^ { \ast } ( s _ { t } ) + \epsilon } ,
$$

where $\epsilon$ is a small constant for numerical stability. Normalization by $\bar { \Phi } ^ { * }$ ensures that discrepancies are penalized more heavily during the early stages (where $\Phi$ is small), as precise guidance is critical initially. We then derive a confidence weight $w _ { t } \in ( 0 , 1 ]$ using a Gaussian kernel with sensitivity $\alpha$ :

$$
w _ { t } = \exp \left( - \alpha \cdot ( \Delta _ { \mathrm { n o r m } } ( s _ { t } ) ) ^ { 2 } \right) .
$$

Conservative State Update. To prevent the policy from exploiting erroneous estimates in OOD scenarios, we employ a conservative update rule for the maintained progress state $\Phi ^ { * } ( s _ { t } )$ instead of Equation (8):

$$
\Phi ^ { * } ( s _ { t } ) = \Phi ^ { * } ( s _ { t - 1 } ) + \frac { w _ { t } } { 2 } \cdot \left( \bar { \Phi } ^ { * } ( s _ { t } ) - \Phi ^ { * } ( s _ { t - 1 } ) + \Delta \Phi _ { t - 1 , t } ^ { \star } \right) .
$$

This mechanism acts as a semantic filter: it ignores uncertain updates when $w _ { t } \to 0$ (retaining $\Phi ^ { * } \mathopen { } \mathclose \bgroup \left( s _ { t - 1 } \aftergroup \egroup \right)$ ) and fully trusts the estimate when consistency is high ( $w _ { t } \to 1$ ).

# 3 Training Data

As shown in Figure 2, RoboBrain 2.5 is trained on a diverse and extensive dataset designed to enhance its capabilities in spatial understanding, temporal modeling and causal reasoning in embodied settings. Specifically, we construct a unified corpus of approximately 12.4M high-quality samples, categorized into three core domains: (1) General MLLM Data for robust semantic perception; (2) Spatial Reasoning Data spanning 2D perception to metric-aware 3D tracing; and (3) Temporal Prediction Data for hierarchical planning and dense value estimation. This mixture strategically balances large-scale web knowledge with fine-grained physical world interactions to bridge the gap between high-level reasoning and low-level control.

![](images/f49c4635c1e2cfd22d6cfa365504c688a4dc0cc5da858796b97e0e09dc8ab8f2.jpg)  
Figure 2 Training Data Distribution for RoboBrain 2.5. The left pie chart illustrates the hierarchical composition of the dataset, structured into Temporal (red), General (teal), and Spatial (blue) domains. The right bar chart displays the sample count for each specific sub-task on a logarithmic scale, highlighting the extensive scale of Dense Value Estimation, High-Quality General Data, and 3D Spatial Reasoning.

# 3.1 General MLLM Data

High-Quality General Data. To establish a robust foundation for general visual perception and reasoning, the general training dataset for RoboBrain 2.5 incorporates approximately 2.83 million high-quality samples. These are primarily sourced and refined from two state-of-the-art open-source collections: Honey-Data-1M [82] and LLaVA-Onevision-1.5-Instruct-Data [5]. (1) Honey-Data-1M Processing. We utilize Honey-Data-1M [82] as a key data source, which provides a diverse set of visual-language instructions designed to enhance multimodal understanding. To align the response style with our embodied agent’s requirements for concise and direct execution commands, we truncated the extensive Chain-of-Thought (CoT) reasoning components, retaining only the final answers to streamline the supervision signal for direct instruction following. (2) LLaVA-Onevision Data Refinement. We further integrate LLaVA-Onevision-1.5-Instruct-Data [5], a comprehensive dataset covering a wide array of visual tasks including OCR, math, and general VQA. To strictly focus on vision-centric capabilities, we first filtered out all text-only samples. To address data imbalance, we applied balanced sampling across each visual-based subclass. Furthermore, to optimize training efficiency and context window utilization, we employed a sample packing strategy where shorter training samples are concatenated. This results in a more uniform sequence length distribution, primarily falling within the 2048 to 8192 token range. (3) De-duplication and Merging. Given the overlap in data sources between these two repositories, we conducted a rigorous de-duplication process to prevent redundancy and data leakage. We filtered the combined pool based on both image similarity and question-answer textual similarity. The final curated dataset consists of 2.83M unique, high-quality multimodal instruction-following samples.

# 3.2 Spatial Reasoning Data

Visual Grounding. The visual grounding dataset is constructed to enhance multimodal understanding through precise object-level localization, leveraging the extensive annotations from LVIS [27]. We carefully curate 152K high-resolution images from LVIS, ensuring broad coverage of diverse object categories and complex visual scenes. Each object annotation is converted into standardized bounding box coordinates $( x _ { 1 } , y _ { 1 } , x _ { 2 } , y _ { 2 } )$ representing the top-left and bottom-right corners, enabling consistent spatial referencing. To facilitate rich visual dialogue, we generated 86K conversational sequences, each containing multiple rounds of QA pairs that progressively explore visual relationships, attribute reasoning, and contextual understanding. The dataset maintains a balanced distribution across object categories while preserving challenging cases of occlusion, viewpoint variation, and rare instances to support robust visual grounding.

Object Pointing. The object pointing dataset is constructed to enable RoboBrain 2.5 to identify the locations of specified objects through pointing within an image. We leverage the Pixmo-Points [22] dataset, which includes 2.3M point annotations across 223K images as our data source. However, direct utilization of Pixmo-Points data for RoboBrain 2.5 training presents challenges due to densely repeated object instances (e.g., books on a shelf). To address this, we implement a two-step filtering process: (1) we discard annotations with more than ten labeled points to simplify training, and (2) we use GPT-4o [31] as a scene analyzer to select only indoor-relevant objects, such as kitchenware, furniture, and decorations, excluding irrelevant or outdoor scenes. This process yields 190K QA pairs for 64K images with reduced clutter, making the data more suitable for embodied contexts. To construct QA pairs for pointing tasks, we construct 28 human-designed templates, such as “Point out all instances of {label} in the image.” or “Help me find {label} in the image by pointing to them.” Here, {label} refers to object categories from the annotations. Templates are randomly selected to ensure linguistic diversity and improve the model’s generalization ability in referencing tasks. For object reference pointing, we incorporate object reference data sourced from RoboPoint [78], which includes 347K QA annotations across 288K images. To address the potential issue of excessive points hindering training convergence, we randomly sample up to ten points per question. Additionally, all coordinates are converted into the normalized values to better support RoboBrain 2.5 training.

Affordance. The affordance dataset focuses on understanding object functionality and spatial vacant areas for placement. For object affordance recognition, we utilize part-level annotations from PACO-LVIS [63], covering 75 object categories and 200 part categories across 46K images. Bounding boxes and segmentation masks are extracted for both whole objects and their functional parts. These annotations are transformed into bounding box coordinates $( x _ { 1 } , y _ { 1 } , x _ { 2 } , y _ { 2 } )$ , serving as ground truth labels for affordance prediction tasks. Questions are constructed using GPT-4o [31] to query object functionality and part usage, e.g., “Which part of a handbag can be grasped to carry it? ” for the handle of a handbag. For whole-object affordances, questions avoid naming the object directly, such as “What device can be moved to control the cursor on a screen? ” for a mouse (computer equipment). This automatic process results in 561K QA pairs. For spatial affordance learning, we include region reference data from RoboPoint [78]. This dataset consists of 270K images with 320K QA pairs and 14 spatial relationship labels. Each annotation is converted into a set of the normalized coordinates $[ ( x _ { 1 } , y _ { 1 } ) , ( x _ { 2 } , y _ { 2 } ) , . . . ]$ , and ground truth points are resampled to a maximum of ten points per answer for optimization. This dataset enables RoboBrain 2.5 to reason about spatial affordances for object placement in real-world settings.

Spatial Understanding. To enhance RoboBrain 2.5’s spatial reasoning, we present the Spatial Understanding Dataset, comprising 826K samples. This dataset emphasizes object-centric spatial attributes (e.g., position, orientation) and inter-object relations (e.g., distance, direction), covering both qualitative and quantitative aspects. It covers 31 distinct spatial concepts, substantially surpassing the ${ \sim } 1 5$ typically found in previous datasets. We partially adopt the RefSpatial [85] pipeline to construct 2D web image and 3D video datasets via automated template- and LLM-based generation: (1) 2D web images aim to provide core spatial concepts and depth perception across diverse indoor and outdoor scenes. To bridge scale and category gaps between these domains, we utilize the large-scale OpenImage [38] dataset. Since direct 3D reasoning from 2D images is challenging, we convert them into pseudo-3D scene graphs. Specifically, after filtering 1.7M images to 466K, we first use RAM [83] for object category prediction and GroundingDINO [49] for 2D boxes Detection. Then we enhance using Qwen2.5-VL [62] and a heuristic method to generate hierarchical captions given the 2D bounding box, ranging from coarse (e.g., “cup”) to fine-grained (e.g., “the third cup from the left”). This enables unambiguous spatial referring in cluttered environments and captures both coarse and fine-grained spatial references. Next, we use UniDepth V2 [60] and WildeCamera [87] for depth and camera intrinsics to enable 3D point cloud reconstruction. Finally, combining this with object boxes from GroundingDINO [49] and masks from SAM 2.1 [64], each scene graph includes object labels, 2D boxes, instance masks, and object-level point clouds, yielding axis-aligned 3D boxes. Object captions serve as nodes, and spatial relations form the edges. QA pairs are generated via templates and LLMs (e.g., QwQ [74]), including object-location questions derived from the hierarchical captions. (2) scanning datasets integrates multimodal 3D scene understanding data from five original datasets: MMScan [50], 3RScan [76], ScanQA [6], SQA3D [51], and SpaceR [58]. We conduct template-based question filtering through rigorous data processing to ensure task relevance, perform multi-stage quality screening (e.g., consistency checks, outlier removal), and standardize all formats into a unified representation. This curation enables fine-grained environmental perception with enhanced reliability, supporting tasks ranging from object localization to complex spatial reasoning in 3D scenes. (3) 3D embodied videos focus on fine-grained spatial understanding in indoor environments. We leverage the CA-1M [39] dataset, filtering 2M frames to 100K high-quality ones. Compared to 2D, the availability of accurate 3D bounding boxes allows us to construct richer scene graphs with more diverse spatial relations, thereby generating more quantitative QA pairs (e.g., size, distances).

Spatial Referring. After enhancing foundational 3D spatial understanding, we extend these capabilities to physical-world interactions by introducing the Spatial Referring Dataset [85], consisting of 802K samples. Unlike prior datasets in visual grounding or object pointing, which often deal with ambiguous or multiple referents, this dataset targets a single unambiguous target, aligning with robotic applications such as precise pick-and-place that demand accurate object identification and localization. Following the RefSpatial [85] construction pipeline, for location data, we sample caption-point pairs from scene graphs built on 2D web images (OpenImage [38]) and 3D embodied videos (CA-1M [39]), using hierarchical captions. For placement data, we leverage fully annotated 3D datasets to generate top-down occupancy maps encoding object positions, orientations, and metric spatial relations (e.g., “10cm right of the chair”), facilitating accurate spatial referring.

3D Spatial Reasoning (RoboBrain 2.5 New Feature). To equip the model with robust 3D spatial reasoning capabilities for tasks such as 3D spatial referring, measuring, and tracing, we introduce the 3D Spatial Reasoning Dataset, comprising 1.74M samples (8.08M QA pairs). Unlike the Spatial Understanding dataset, which focuses on qualitative, metric-agnostic spatial concepts (e.g., left, far, inside), this part is metricgrounded and supports flexible output in appropriate units (e.g., cm, inch, m). Following the TraceSpatial [86] construction pipeline, we propose a data pipeline that progressively integrates 3D scanning and video sources to perform 3D spatial referring, measuring, and tracing. (1) 3D Scanning datasets want to arm the model with a focused metric-grounded spatial reasoning of indoor scenes. We thus leverage the richly annotated CA-1M [39] and ScanNet [21]. After fine-grained filtering, similar to the Spatial Understanding part, we construct pseudo-3D scene graphs with more diverse spatial relations, enabled by precise 3D bounding boxes compared to 2D approaches. Moreover, we generate 3D occupancy maps that encode positions, orientations, and metric distances (e.g., “35cm right of the toy”) for accurate object-centric spatial trace generation. (2) Manipulation videos provide spatial traces aligned with the embodied manipulation in tabletop settings. While 3D scans enable object-centric tracing, they lack physically plausible manipulations for robotics. Hence, we curate both real (e.g., AgiBot-Beta [19], DROID [36]) and simulated (e.g., RoboTwin 2.0 [17]) tabletop videos. Through a rigorous data cleaning process, such as verifying valid camera poses, coherent task flows, and clean trajectories, we reduce the dataset from 167K to 59K samples for AgiBot-Beta, and from 116K to 24K for DROID. We further leverage Qwen3-VL [62] to decompose these tasks into subgoals, enabling precise multi-step spatial tracing for single-/dual-arm across 3 robot configurations.

# 3.3 Temporal Prediction Data

Ego-View Planning. We construct Ego-View Planning dataset by partially processing the EgoPlan-IT [18] dataset, which contains 50K automatically generated samples. For each selected task instance, we extract multiple frames from prior actions to represent task progress, and one frame to capture the current viewpoint. To enhance linguistic variety, we use multiple prompt templates that describe the task goal, video context, and current observation. Each question includes the correct next action along with up to three distractor actions randomly sampled from negative examples. This setup supports multimodal instruction tuning with diverse visual and textual input, aimed at improving egocentric task planning performance.

ShareRobot Planning. The ShareRobot dataset [33] is a large-scale, fine-grained resource for robotic manipulation, offering multi-dimensional annotations tailored for task planning. Its planning component provides detailed low-level instructions aligned with individual video frames, effectively transforming high-level task descriptions into structured and executable sub-tasks. Each data instance includes precise planning annotations to support accurate and consistent task execution. The dataset comprises 1M QA pairs from 51K instances, spanning 102 diverse scenes across 12 robot embodiments and 107 atomic tasks filtered according to the Open-X-Embodiment taxonomy [59]. All planning data were meticulously annotated by human experts following the RoboVQA [65] format, enabling models to learn robust multi-step planning strategies grounded in diverse real-world scenarios. The scale, quality, and diversity of ShareRobot help improve the model’s ability to perform fine-grained reasoning and task decomposition in complex embodied environments.

AGIbot Planning. The AgiBot Planning dataset is a large-scale robotics task planning dataset built upon the AgiBot-World [12] dataset, comprising 9,148 QA pairs across 19 manipulation tasks with 109,378 firstperson perspective images. Each sample contains 4-17 consecutive frames documenting task progression with multimodal conversational format. AgiBot-Planning provides step-by-step planning instructions that transform high-level goals into executable sub-tasks. Each data point includes current objectives, historical steps, and required subsequent actions. The dataset covers diverse scenarios from household refrigerator operations to supermarket shopping tasks across different environments. The meticulously crafted annotations use standardized conversational formats, enabling models to learn from varied real-world contexts. Through continuous visual sequences and fine-grained action plans, AgiBot-Planning enhances RoboBrain 2.5’s ability to perform long-horizon task planning and spatial reasoning in complex embodied scenarios.

Multi-Robot Planning. The Multi-Robot Planning dataset is constructed by simulating collaborative task scenarios across three environments—household, supermarket, and restaurant—based on RoboOS [68, 69]. Each sample is generated using structured templates that specify a detailed scene graph, robot specifications, and associated tool lists. For every scenario, we design high-level, long-horizon collaborative task goals that require coordination among multiple robots present in the scene, and generate corresponding workflow graphs that decompose the tasks into subtasks with detailed reasoning explanations. Based on these decompositions, we further generate agent-specific robotic tool plans that translate high-level task goals into precise low-level Observation-Action pairs for each subtask. Specifically, we define 1,659 types of multi-robot collaboration tasks across the three environments and produce 44,142 samples using DeepSeek-V3 [46].

Close-Loop Interaction. The Close-Loop Interaction dataset is designed to facilitate advanced embodied reasoning [84], featuring a large-scale collection of synthesized Observation-Thought-Action (OTA) trajectories that combine first-person visual observations with structured thought tokens. It spans 120 diverse indoor environments—including kitchens, bathrooms, bedrooms, and living rooms—containing over 4,000 interactive objects and receptacles. The dataset is constructed within the AI2Thor [37] simulator through a rigorous multistage pipeline based on Embodied-Reasoner [81], which includes: (1) crafting task instructions from constrained templates to ensure scene-appropriate validity; (2) deriving key action sequences from an object-affiliation graph encoding functional relationships; and (3) strategically incorporating search actions to emulate realistic exploration. To enrich the depth of reasoning, GPT-4o [31] generates detailed thought processes—covering situational analysis, spatial reasoning, self-reflection, task planning, and verification—which are seamlessly integrated between observations and actions, forming coherent reasoning chains that guide models through complex, long-horizon interactive tasks.

Dense Value Estimation (RoboBrain 2.5 New Feature). To empower the dense temporal value estimator with robust generalization capabilities, we construct a comprehensive dataset comprising approximately 35 million value estimation samples derived from over 27 million raw frames, and then down-sample to 3.5M for final training. Following the Dopamine-Reward [67] pipeline, this corpus is meticulously aggregated from three complementary domains, strategically balanced to bridge the gap between physical reality and semantic understanding: (1) Real-World robot data, which constitutes the majority $( \sim 6 0 \% )$ of the training set, integrating diverse datasets such as AGIBot-World [12], DROID [36], and RoboBrain-X [25] to ground the model in physical interaction dynamics across varied environments; (2) Simulation data $( \sim 1 3 \% )$ , incorporating benchmarks like LIBERO [47], RoboCasa [55], and RoboTwin [17] to foster strong instruction-following capabilities through high-quality, occlusion-free labels; and (3) Human-Centric data $( \sim 2 6 \% )$ , leveraging the massive scale of EgoDex [30] to acquire universal object affordance priors independent of robot morphology. Crucially, this heterogeneous mixture spans a wide spectrum of embodiments, ranging from single-arm industrial robots (e.g., Franka Emika Panda) to complex bimanual humanoids (e.g., AGIBot-A2D), preventing overfitting to specific kinematics and ensuring the model focuses on object state changes. We apply the hop-based labeling strategy described in Section 2.2 to this multi-source collection, enabling the model to provide stable, embodiment-invariant progress feedback across a wide spectrum of tasks.

# 4 Training Strategy

Similar to RoboBrain 2.0 [72], RoboBrain 2.5 achieves embodied capabilities (spatial understanding, temporal modeling) through a progressive dual-phase training strategy, as shown in Table 1. Starting from a robust vision-language foundation, we introduce escalating complexity in embodied supervision, enabling the model to evolve from static perception to dynamic reasoning and actionable planning in real-world environments. Specifically, the training pipeline is divided into two distinct phases: (1) Foundational Spatiotemporal Learning, which establishes broad visual semantics, 2D spatial grounding, and open-loop planning capabilities; and (2) Specific Spatiotemporal Enhancement, which fine-tunes the model on quantitative 3D spatial reasoning and dense temporal value estimation to ensure precise, metric-aware physical interaction.

Table 1 Detailed configuration for each training stage of the RoboBrain 2.5.   

<table><tr><td rowspan=2 colspan=1></td><td rowspan=1 colspan=2>NVIDIA GPUS</td><td rowspan=1 colspan=2>Moore Threads GPUs</td></tr><tr><td rowspan=1 colspan=1>Stage-1</td><td rowspan=1 colspan=1>Stage-2</td><td rowspan=1 colspan=1>Stage-1</td><td rowspan=1 colspan=1>Stage-2</td></tr><tr><td rowspan=1 colspan=1>D    Dataset#Samples</td><td rowspan=1 colspan=1>Foundational Learning8.3 M</td><td rowspan=1 colspan=1>Specific Learning4.1 M</td><td rowspan=1 colspan=1>Foundational Learning8.3 M</td><td rowspan=1 colspan=1>Specific Learning4.1 M</td></tr><tr><td rowspan=1 colspan=1>0    Trainable Part#Tunable Parameters</td><td rowspan=1 colspan=1>Full Model8B</td><td rowspan=1 colspan=1>Full Model8B</td><td rowspan=1 colspan=1>Full Model8B</td><td rowspan=1 colspan=1>Full Model8B</td></tr><tr><td rowspan=3 colspan=1>Global Batch SizeTensor Parallelism (TP)Pipeline Parallelism (PP)</td><td rowspan=1 colspan=1>1024</td><td rowspan=1 colspan=1>1024</td><td rowspan=1 colspan=1>1024</td><td rowspan=6 colspan=1>1024221×10−6, 1×10−51AdamW</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>2</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>2</td><td rowspan=2 colspan=1>21×10−6, 1×10−5</td><td rowspan=2 colspan=1></td></tr><tr><td rowspan=1 colspan=1>LR: {ψνit, φLM}</td><td rowspan=1 colspan=1>1×10−6, 1×10−5</td><td rowspan=1 colspan=1>1×10−6, 1×10−5</td></tr><tr><td rowspan=1 colspan=1>Epoch</td><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>1</td><td rowspan=2 colspan=1>1AdamW</td></tr><tr><td rowspan=2 colspan=1>OptimizerWeight Decay</td><td rowspan=1 colspan=1>AdamW</td><td rowspan=1 colspan=1>AdamW</td></tr><tr><td rowspan=1 colspan=1>0.1</td><td rowspan=1 colspan=1>0.1</td><td rowspan=1 colspan=1>0.1</td><td rowspan=1 colspan=1>0.0</td></tr><tr><td rowspan=1 colspan=1>Warmup Ratio</td><td rowspan=1 colspan=1>0.01</td><td rowspan=1 colspan=1>0.01</td><td rowspan=1 colspan=1>0.03</td><td rowspan=1 colspan=1>0.00</td></tr><tr><td rowspan=1 colspan=1>LR Schedule</td><td rowspan=1 colspan=1>Cosine</td><td rowspan=1 colspan=1>Cosine</td><td rowspan=1 colspan=1>Cosine</td><td rowspan=1 colspan=1>Cosine</td></tr><tr><td rowspan=1 colspan=1>Max Seq. Length</td><td rowspan=1 colspan=1>16384</td><td rowspan=1 colspan=1>16384</td><td rowspan=1 colspan=1>16384</td><td rowspan=1 colspan=1>16384</td></tr><tr><td rowspan=1 colspan=1>GPU Nums</td><td rowspan=1 colspan=1>64 × 8</td><td rowspan=1 colspan=1>64 × 8</td><td rowspan=1 colspan=1>128 × 8</td><td rowspan=1 colspan=1>128 × 8</td></tr></table>

# 4.1 Stage 1: Foundational Spatiotemporal Learning

In the first stage, we focus on establishing a robust “Generalist Brain” capable of understanding multimodal instructions, grounding objects in 2D space, and mastering high-level planning logic. We utilize the Full Model across 8.3 million samples, comprising the General MLLM Data, Spatial Reasoning Data (excluding metric 3D points/traces), and Temporal Prediction Data (Planning and pairwise comparisons). To ensure stable convergence on this heterogeneous corpus, we employ a standard next-token prediction loss. The primary objectives of this stage are threefold: (1) General Visual Perception: Leveraging high-quality general data (e.g., Honey-Data-1M) to maintain and enhance the model’s general visual-linguistic capabilities. This ensures the model retains a robust understanding of open-world semantics, complex user queries, and diverse visual scenes, serving as a versatile foundation for specific embodied tasks. (2) 2D Grounding & Qualitative 3D Understanding: Beyond standard 2D visual grounding and affordance detection, this stage incorporates text-based QA from the 3D Spatial Reasoning dataset. This enables the model to comprehend complex spatial relationships (e.g., spatial relations, occupancy) and qualitative 3D concepts without the burden of precise metric coordinate regression. (3) Planning & Temporal Logic: We integrate diverse planning datasets to teach logical task decomposition. Furthermore, we introduce a Temporal Value Comparison task derived from the Dense Value Estimation dataset. Instead of predicting absolute values, the model learns to order keyframes temporally (i.e., identifying which frame represents a later state), establishing a preliminary awareness of task progress and state evolution. This stage yields a model proficient in general perception, logical planning, and qualitative spatiotemporal reasoning, providing a solid initialization for fine-grained training.

# 4.2 Stage 2: Specific Spatiotemporal Enhancement

To bridge the gap between semantic understanding and physical actuation, the second stage introduces Specific Spatiotemporal Enhancement, focusing on precise quantitative reasoning. This stage utilizes approximately 4.1 million samples, targeting the newly introduced Metric 3D Spatial Reasoning and Dense Value Estimation capabilities. (1) Metric-Aware 3D Tracing. We introduce the specific 3D data focusing on point and trajectory generation to transition the model from qualitative understanding to quantitative perception. This enables the model to predict absolute 3D coordinates, depth-aware traces, and metric distances (e.g., in centimeters), which are critical for precision manipulation tasks. (2) Dense Value Estimation. We transition from pairwise comparison to explicit Hop prediction. The model is trained to act as a robust value function (Critic) by predicting continuous progress values (Hops) frame-by-frame, enabling it to provide fine-grained, closed-loop feedback for policy ranking and error recovery. (3) Anti-Forgetting Strategy. To prevent the catastrophic forgetting of general capabilities while learning these specialized metric tasks, we adopt a data replay strategy. We randomly sample $1 5 \%$ of the Stage-1 data and mix it with the Stage-2 specific data. This ensures the model retains its conversation, 2D grounding, and logical planning abilities while mastering fine-grained physical skills for 3D embodied environment.

# 5 Infrastructure

During the training of RoboBrain 2.5, we build upon the infrastructure established in RoboBrain 2.0 [33, 72] while further strengthening and systematizing the core training pipeline. The overall system adopts a multi-dimensional hybrid parallelism strategy, combined with distributed data loading optimizations, and a deeply optimized memory pre-allocation mechanism tailored for multi-modal long-sequence training. These improvements significantly enhance hardware utilization efficiency and overall training throughput.

On the data side, our implementation is based on the Megatron–Energon [40] framework with substantial in-house optimizations. This design enables unified format representation and online mixed training of heterogeneous modalities, including text, single-image, multi-image, and video samples. At the same time, we strictly preserve intra-dataset sample ordering to satisfy the requirements of instruction alignment and temporal consistency. By adopting a customized WebDataset [4] sample format, the system achieves compatibility with diverse data types while substantially reducing offline preprocessing overhead and improving the flexibility and extensibility of the data pipeline.

# 5.1 Hybrid Parallelism

Multi-modal large models exhibit pronounced heterogeneity in both model architecture and computational characteristics [48]. The visual component typically consists of a relatively lightweight ViT-based encoder (with adapter modules), whereas the language component is dominated by a large-scale decoder-only architecture. Although the visual encoder has a smaller parameter footprint, its computational cost becomes non-trivial when training with a high proportion of visual or video samples.

To address this architectural heterogeneity, we leverage the heterogeneous training experience accumulated in our in-house distributed framework, FlagScale [20], and adopt an uneven pipeline parallelism strategy [56]. Specifically, the ViT module is placed at the front of the model, and the number of language layers assigned to the first pipeline stage is reduced accordingly. This design balances computational load across pipeline stages, mitigates pipeline bubbles, and improves overall pipeline efficiency.

# 5.2 Dynamic pre-Allocated Memory

In RoboBrain 2.5 training, sequence lengths vary significantly across samples. Combined with PyTorch’s default CUDA caching memory allocator, this dynamic-shape workload often leads to severe GPU memory fragmentation and, in extreme cases, out-of-memory (OOM) failures. A common workaround is to invoke torch.cuda.empty_cache() [61] before each iteration; however, this approach disrupts memory reuse and substantially degrades training performance.

To resolve this issue, we conduct an in-depth analysis of CUDA memory allocation and reuse behavior and propose a dynamic unified padding strategy based on dual data streams.

• Before training begins, the maximum sequence length observed in the training set is collected;   
• In the first training iteration, all samples are padded to this maximum length, enabling one-time memory pre-allocation during initialization;   
• In subsequent iterations, tensors reuse the pre-allocated memory, effectively suppressing memory fragmentation;   
• Only when the visual token length exceeds the current maximum does the system trigger a full cache cleanup and re-pad samples to the new maximum length.

This strategy strikes a practical balance between memory efficiency and training performance, providing both stability and high throughput in large-scale multi-modal long-sequence training scenarios.

# 5.3 Cross-Accelerator Training and Inference

Leveraging FlagScale’s distributed training capabilities on heterogeneous accelerator clusters, together with VLM-specific kernel and communication optimizations, we successfully complete end-to-end training of RoboBrain 2.5 on a thousand-device cluster composed of non-NVIDIA accelerators. The resulting loss convergence behavior closely matches that observed on NVIDIA platforms, with the final convergence gap controlled within $0 . 6 2 \%$ .

Furthermore, the trained checkpoints are seamlessly migrated to NVIDIA-based platforms for downstream evaluation. Across a range of mainstream benchmarks, the resulting performance remains highly consistent with models trained natively on NVIDIA hardware. This RoboBrain 2.5 case study demonstrates that FlagOS/FlagScale’s cross-accelerator training and inference capabilities have matured to a level that is reliable, practical, and production-ready for large-scale multi-modal model training.

# 6 Evaluation Results

We conducted a comprehensive evaluation of RoboBrain-2.5, significantly expanding the assessment scope of its predecessor to include 3D quantitative spatial reasoning and fine-grained temporal value estimation. To ensure consistency and rigor, we continued to employ FlagEvalMM [29], our flexible framework for systematic multimodal model assessment. Notably, to demonstrate the cross-platform robustness of our training infrastructure, we report performance for RoboBrain-2.5 variants trained on two distinct hardware backends: NVIDIA (NV) GPUs and Moore-Threads (MTT) GPUs.

Evaluations on spatial reasoning benchmarks, which now encompass both foundational 2D tasks (e.g., CVBench [75], RoboSpatial [66]) and advanced 3D quantitative measurement (e.g., MSMU [14], TraceSpatial [86], VABench-V [79]), are presented in Section 6.1 and Section 6.2. Furthermore, we introduce a new dimension of evaluation for temporal value estimation in Section 6.3, leveraging the General Process Reward Modeling (GPRM) paradigm from Robo-Dopamine [67]. We assess the model’s ability to perceive manipulation progress across diverse data sources, organized into Real-Bench (real-world robot data including AgiBot [12], DROID [36], and Galaxea [35]), Sim-Bench (simulation environments like Libero [47]and RoboCasa [55]), and Human-Bench (human manipulation videos from EgoDex [30]). Qualitative examples are provided in Section A.

Table 2 Performance on 2D spatial reasoning benchmarks. The best results are highlighted in bold, while the second-best results are underlined. Results marked with \* are sourced from their technical reports.   

<table><tr><td rowspan="2">Models / Metrics</td><td colspan="5">2D Spatial Reasoning</td><td rowspan="2">AVG All↑</td></tr><tr><td>CV-Bench</td><td>CrossPoint</td><td>RoboSpatial</td><td>RefSpatial</td><td>EmbSpatial</td></tr><tr><td>General Baselines</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Gemini-3-Pro-Preview [26]</td><td>92.00*</td><td>38.60</td><td>57.96</td><td>65.50*</td><td>76.62</td><td>66.14</td></tr><tr><td>GPT-5.2 [57]</td><td>86.84</td><td>33.00</td><td>43.78</td><td>15.00</td><td>68.02</td><td>49.33</td></tr><tr><td>Qwen3-VL-8B-Inst. [8]</td><td>92.89</td><td>28.40</td><td>66.90*</td><td>54.20*</td><td>78.50*</td><td>64.18</td></tr><tr><td>Embodied Baselines</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>RoboBrain-2.0 (7B) [72]</td><td>85.75*</td><td>26.00</td><td>54.23*</td><td>32.50*</td><td>76.32*</td><td>54.96</td></tr><tr><td>Mimo-Embodied (7B) [28]</td><td>88.82*</td><td>20.02</td><td>61.76*</td><td>48.00*</td><td>76.24*</td><td>58.97</td></tr><tr><td>RoboBrain-2.5 (8B) NV</td><td>94.58</td><td>75.40</td><td>73.03</td><td>60.50</td><td>75.58</td><td>75.82</td></tr><tr><td>RoboBrain-2.5 (8B) MTT</td><td>93.90</td><td>76.30</td><td>73.00</td><td>59.00</td><td>76.92</td><td>75.82</td></tr></table>

# 6.1 2D Spatial Reasoning Capability

We first evaluate RoboBrain-2.5 on five representative 2D spatial reasoning benchmarks: CV-Bench [75], CrossPoint [77], RoboSpatial [66], RefSpatial [85], and EmbSpatial [24]. Results are summarized in Table 2. Overall, the RoboBrain-2.5 variants trained on the NVIDIA GPU Platform and Moore-Threads (MTT) GPU Platform achieve same average scores of 75.82. Both deliver substantial improvements over general-purpose and embodied baselines.

• CV-Bench [75]. CV-Bench assesses vision-centric spatial understanding and visual processing via repurposed 2D/3D vision tasks. RoboBrain-2.5 (8B) trained on NVIDIA achieves the best accuracy of 94.58, with the MTT variant closely following at 93.90. Both consistently outperform strong general baselines such as Qwen3-VL-8B-Inst. (92.89), Gemini-3-Pro-Preview (92.00), and GPT-5.2 (86.84), as well as embodied baselines including RoboBrain-2.0 (7B) (85.75) and Mimo-Embodied (7B) (88.82), indicating a clear gain in foundational 2D spatial perception.   
• CrossPoint [77]. CrossPoint-Bench evaluates cross-view point correspondence, requiring fine-grained pointlevel matching across different viewpoints. RoboBrain-2.5 demonstrates a decisive advantage, achieving 76.30 (MTT) and 75.40 (NVIDIA), which substantially surpasses all evaluated baselines, including Gemini3-Pro-Preview (38.60), GPT-5.2 (33.00), Qwen3-VL-8B-Inst. (28.40), RoboBrain-2.0 (7B) (26.00), and Mimo-Embodied (7B) (20.02). This highlights the model’s strong capability in transitioning from coarse spatial judgment to actionable, coordinate-level correspondence.   
• RoboSpatial [66]. RoboSpatial measures spatial reasoning in robotics-oriented environments, emphasizing egocentric understanding, reference frames, and interaction-relevant spatial relations. RoboBrain-2.5 achieves the best scores of 73.03 (NVIDIA) and 73.00 (MTT), outperforming Qwen3-VL-8B-Inst. (66.90) and Gemini-3-Pro-Preview (57.96), as well as embodied baselines like Mimo-Embodied (7B) (61.76) and RoboBrain-2.0 (7B) (54.23). The consistent gains suggest improved spatial grounding for robot-centric perception and interaction.   
RefSpatial [85]. RefSpatial evaluates spatial referring under complex spatial constraints, demanding precise grounding with multi-step spatial reasoning. RoboBrain-2.5 achieves strong results of 60.50 (NVIDIA) and 59.00 (MTT), substantially exceeding Qwen3-VL-8B-Inst. (54.20), Mimo-Embodied (7B) (48.00), RoboBrain-2.0 (7B) (32.50), and GPT-5.2 (15.00), while remaining competitive with the best-performing general baseline (Gemini-3-Pro-Preview, 65.50). This indicates robust spatial referring performance in cluttered, instruction-conditioned settings.   
• EmbSpatial [24]. EmbSpatial-Bench assesses embodied spatial understanding from an egocentric perspective. RoboBrain-2.5 attains competitive performance with 76.92 (MTT) and 75.58 (NVIDIA), closely matching Gemini-3-Pro-Preview (76.62) and surpassing GPT-5.2 (68.02), while approaching the strongest baseline Qwen3-VL-8B-Inst. (78.50). These results suggest that RoboBrain-2.5 achieves strong generalization in embodied spatial relations, with minimal sensitivity to the training hardware backend.

Table 3 Performance on five 3D spatial reasoning benchmarks. For TraceSpatial, we further report fine-grained 3D metrics including 3D Start, 3D End, and Success for the detailed trace evaluation. The best results among different models are highlighted in bold, while the second-best results are underlined.   

<table><tr><td rowspan="2">Models / Metrics</td><td colspan="7">3D Spatial Reasoning</td></tr><tr><td>MSMU ↑</td><td>Q-Spatial ↑</td><td></td><td>TraceSpatial↑</td><td></td><td>VABench-V ↓</td><td>ShareRobot-T ↓</td></tr><tr><td>General Baselines</td><td></td><td></td><td>3D Start</td><td>3D End</td><td>Success</td><td></td><td></td></tr><tr><td colspan="10"></td></tr><tr><td>Gemini-3-Pro-Preview [26]</td><td>59.44</td><td>81.37</td><td>19</td><td>25</td><td>7</td><td>0.1705</td><td>0.1899</td></tr><tr><td>GPT-5.2 [57]</td><td>57.96</td><td>69.16</td><td>3</td><td>8</td><td>0</td><td>0.1962</td><td>0.2379</td></tr><tr><td>Qwen3-VL-8B-Inst. [8]</td><td>43.48</td><td>70.74</td><td>30</td><td>20</td><td>6</td><td>0.1979</td><td>0.2347</td></tr><tr><td colspan="10">Embodied Baselines</td></tr><tr><td>RoboBrain-2.0 (7B) [72]</td><td>55.01</td><td>63.37</td><td></td><td></td><td></td><td></td><td>0.1240</td></tr><tr><td>Mimo-Embodied (7B) [28]</td><td>46.36</td><td>65.42</td><td></td><td></td><td></td><td>0.6970</td><td>0.66351</td></tr><tr><td>RoboBrain-2.5 (8B) NV</td><td>64.17</td><td>73.53</td><td>83</td><td>63</td><td>44</td><td>0.1281</td><td>0.1164</td></tr><tr><td>RoboBrain-2.5 (8B) MTT</td><td>61.66</td><td>78.31</td><td>80</td><td>65</td><td>36</td><td>0.1189</td><td>0.1171</td></tr></table>

# 6.2 3D Spatial Reasoning Capability

We further evaluate RoboBrain-2.5 on five 3D spatial reasoning benchmarks that stress metric-grounded and trajectory-aware understanding: MSMU [14], Q-Spatial [45], TraceSpatial [86], VABench-V [79], and ShareRobot-Bench [33]. Results are summarized in Table 3. Unless otherwise noted, higher is better; specifically for VABench-V and ShareRobot-Bench, we report distance-based metrics where lower indicates better performance.

• MSMU [14]. MSMU evaluates quantitative 3D spatial measuring and understanding with precise numerical annotations. RoboBrain-2.5 achieves the best performance, with 64.17 (NVIDIA) and 61.66 (MTT), surpassing strong general baselines such as Gemini-3-Pro-Preview (59.44) and GPT-5.2 (57.96), as well as embodied baselines like RoboBrain-2.0 (55.01) and Mimo-Embodied (46.36), indicating substantially improved metric-grounded perception. Q-Spatial [45]. Q-Spatial Benchmark assesses quantitative reasoning about object sizes and distances in images. RoboBrain-2.5 (MTT) achieves a strong score of 78.31, outperforming Qwen3-VL-8B-Inst. (70.74), GPT-5.2 (69.16), RoboBrain-2.0 (63.37), and Mimo-Embodied (65.42), while remaining competitive with the best-performing general baseline (Gemini-3-Pro-Preview, 81.37). This demonstrates robust quantitative spatial reasoning without specialized test-time prompting.   
• TraceSpatial [86]. TraceSpatial-Bench evaluates multi-step, metric-grounded spatial tracing in cluttered 3D scenes, where a prediction is considered successful only if the trajectory satisfies correct start/end spatial constraints and remains collision-free. We report three fine-grained 3D metrics: 3D Start measures grasp success (whether the predicted start point is sufficiently close to the target object point cloud), 3D End measures placement success (whether the predicted end point falls inside/near the destination object’s 3D bounding box), and Success measures the final spatial trace success by jointly considering grasp success, placement success, and collision checking along the trace [86].   
• VABench-V [79]. VABench-V evaluates visual trace generation from natural language instructions with distance-based metrics (RMSE) (lower is better). RoboBrain-2.5 achieves a clear SOTA with a lowest error of 0.1189 (MTT) and a close second-best of 0.1281 (NVIDIA), substantially improving over Gemini3-Pro-Preview (0.1705), GPT-5.2 (0.1962), and Qwen3-VL-8B-Inst. (0.1979), demonstrating accurate fine-grained waypoint generation.   
• ShareRobot-T [33]. ShareRobot-Traj Benchmark assesses robot-centric spatial grounding for interaction and trajectory-related prediction (RMSE), where lower distance indicates better performance. RoboBrain2.5 attains the best results with 0.1164 (NVIDIA) and a close second of 0.1171 (MTT), improving over RoboBrain-2.0 (0.1240) and strongly outperforming general baselines such as Gemini-3-Pro-Preview (0.1899) and GPT-5.2 (0.2379), reflecting more precise interaction-relevant spatial outputs.

Table 4 Temporal value estimation on six testsets. We report VOC+ / VOC $-$ (both ↑), where $\mathrm { V O C ^ { - } }$ is computed by reversing the video and re-evaluating the model. The best results among different models are highlighted in bold, while the second-best results are underlined.   

<table><tr><td rowspan="2">Models /Metrics</td><td colspan="10">voc+/voc-()</td><td rowspan="2" colspan="2"></td></tr><tr><td>AgiBot</td><td colspan="2"></td><td colspan="2">Galaxea</td><td colspan="2">EgoDex</td><td colspan="2">LIBERO</td><td colspan="2">RoboCasa</td></tr><tr><td colspan="10">General Baselines</td><td colspan="3"></td></tr><tr><td>Gemini-3-Pro-Preview [26]</td><td>81.36 /</td><td>58.70</td><td>90.57 /</td><td>44.15</td><td>88.86 /</td><td>35.34</td><td>80.48 /</td><td>50.15</td><td>98.42</td><td>76.31</td><td>67.89</td><td>34.28</td></tr><tr><td>GPT-5.2 [57]</td><td>90.02 /</td><td>15.91</td><td>91.45 /</td><td>15.29</td><td>88.76 /</td><td>10.03</td><td>78.12</td><td>22.79</td><td>96.97</td><td>19.19</td><td>77.91</td><td>10.71</td></tr><tr><td>Qwen3-VL-8B-Inst. [8]</td><td>82.50 / 5.32</td><td></td><td>81.33 /</td><td>10.37</td><td>79.98</td><td>/5.51</td><td>63.85 /</td><td>12.82</td><td>72.31</td><td>22.07</td><td></td><td>59.11 / -0.03</td></tr><tr><td colspan="9">Embodied Models</td><td colspan="3"></td></tr><tr><td>RoboBrain-2.5 (8B) NV</td><td>83.08 7</td><td>88.58</td><td>90.82</td><td>90.07</td><td>93.38</td><td>95.79</td><td>79.14</td><td>84.99</td><td>98.97</td><td>98.94</td><td>98.47</td><td>98.75</td></tr><tr><td>RoboBrain-2.5 (8B) MTT</td><td>87.36 / 87.48</td><td></td><td>93.67</td><td>/ 89.26</td><td>94.58</td><td>94.54</td><td>80.67</td><td>81.12</td><td>98.88</td><td>/98.91</td><td>98.54</td><td>99.58</td></tr></table>

# 6.3 Temporal Value Estimation

To evaluate fine-grained temporal value estimation for manipulation progress, we follow the General Process Reward Modeling (GPRM) paradigm in Robo-Dopamine [67]. Concretely, the model is prompted with a task instruction and conditioned on multi-view images of the initial and goal states, together with paired multi-view observations of the BEFORE and AFTER states, and predicts a discretized relative progress/regress hop as a value signal [67]. We evaluate temporal ordering robustness via two rank-correlation metrics: Forward VOC $( \mathsf { V O C } ^ { + } )$ ) computed on the original temporal direction, and Reverse VOC $( \mathsf { v o c ^ { - } } )$ computed by time-reversing the video and re-evaluating the model (i.e., the predicted value should consistently invert with the reversed temporal order). We report VOC $^ +$ / VOC $^ -$ (both $\uparrow$ ) on six data sources spanning real-robot, simulation, and human egocentric videos: AgiBot [12], DROID [36], Galaxea [35], EgoDex [30], LIBERO [47], and RoboCasa [55]. Results are summarized in Table 4.

• AgiBot [12]. On AgiBot, the RoboBrain-2.5 variants demonstrate strong and balanced performance. Specifically, the model trained on Moore-Threads (MTT) achieves 87.36 / 87.48, ranking second in Forward VOC while maintaining high consistency. In contrast, while generalist VLMs like GPT-5.2 achieve a higher Forward VOC (90.02), they exhibit substantially lower Reverse VOC (15.91), indicating a lack of robust bidirectional temporal understanding compared to our embodied models.   
• DROID [36]. On DROID, RoboBrain-2.5 (MTT) attains a clear lead with 93.67 / 89.26, substantially improving over all baselines. While GPT-5.2 achieves the second-best Forward VOC (91.45), its Reverse VOC drops sharply to 15.29. Similarly, Gemini-3-Pro-Preview shows a large gap between forward (90.57) and reverse (44.15) performance, again highlighting the benefit of RoboBrain-2.5’s step-aware progress supervision. Galaxea [25]. On Galaxea, both RoboBrain-2.5 variants perform exceptionally well, with the MTT variant reaching 94.58 / 94.54 and the NVIDIA variant closely following at 93.38 / 95.79. General baselines show significantly weaker Reverse VOC (e.g., Gemini-3-Pro-Preview at 35.34 and GPT-5.2 at 10.03), suggesting that high forward correlation alone is insufficient without robust time-reversal behavior.   
• EgoDex [30]. On EgoDex (human egocentric manipulation videos), RoboBrain-2.5 (MTT) achieves the best comprehensive result (80.67 / 81.12). While Gemini-3-Pro-Preview shows competitive Forward VOC (80.48), its Reverse VOC (50.15) is significantly lower. This indicates that RoboBrain-2.5 generalizes better to human-centric temporal cues while maintaining logical consistency across temporal directions.   
• LIBERO [47]. On LIBERO, both RoboBrain-2.5 models achieve near-ceiling performance, with the NVIDIA variant reaching 98.97 / 98.94 and the MTT variant close behind at 98.88 / 98.91. Although general baselines show relatively high Forward VOC (e.g., Gemini-3-Pro-Preview at 98.42), their lower Reverse VOC (76.31 or below) reinforces that bidirectional temporal consistency is a stricter criterion for progress-aware value modeling.   
• RoboCasa [55]. On RoboCasa, RoboBrain-2.5 (MTT) achieves the best performance (98.54 / 99.58), followed closely by the NVIDIA variant. Compared to general baselines (e.g., GPT-5.2 at 77.91 / 10.71), the RoboBrain-2.5 models demonstrate markedly stronger robustness under time reversal, consistent with the design goal of providing reliable, step-aware progress signals for manipulation [67].

# 7 Conclusion and Future Works

In this work, we introduced RoboBrain-2.5, a next-generation embodied AI foundation model that significantly bridges the gap between high-level semantic reasoning and low-level physical interaction. By addressing the fundamental limitations of prior generalist models—specifically the lack of metric-grounded spatial precision and the absence of dense temporal supervision—RoboBrain-2.5 achieves a comprehensive upgrade in embodied capabilities. Our contributions are established through two core pillars. First, we proposed Precise 3D Spatial Reasoning, moving beyond 2D pixel-relative grounding to depth-aware coordinate prediction. By utilizing a decoupled $( u , v , d )$ representation and training on high-quality 3D spatial data, the model learns to interpret absolute metric constraints and generate collision-free, trajectory-level manipulation traces. Second, we introduced Dense Temporal Value Estimation, a mechanism that provides fine-grained, step-aware progress and regress feedback. This capability, powered by a hop-based labeling strategy and multi-perspective fusion, enables the model to serve as a robust general-purpose reward function resilient to viewpoint variations. Furthermore, we demonstrated the scalability of our approach through a robust infrastructure capable of cross-accelerator training on both NVIDIA and Moore Threads GPUs. Extensive evaluations confirm that RoboBrain-2.5 sets a new state-of-the-art on both spatial reasoning and temporal value estimation tasks. In future research, we plan to expand the capabilities and efficiency of the RoboBrain model series in four primary directions:

• Unified Generation and Understanding Paradigm: We aim to evolve RoboBrain into a unified architecture that integrates both spatiotemporal understanding and generative capabilities. By incorporating image and video prediction (i.e., next-stage prediction), the model will serve as an embodied world model. This will enable agents to simulate action outcomes in their “mind” before execution, significantly enhancing planning safety and robustness in complex environments.   
• Deployment on Mobile Manipulation and Humanoids: We will extensively validate and deploy our models on diverse real-world platforms, including mobile manipulators and humanoid robots [16, 41–44]. Our focus will be on leveraging Precise 3D Spatial Reasoning to achieve training-free manipulation generalization, while utilizing Dense Temporal Value Estimation as a high-fidelity reward signal to drive efficient Reinforcement Learning (RL) in the physical world.   
• Scalable Model Family and Specialized Variants: To accommodate varying computational constraints and latency requirements, we plan to release a comprehensive series of models with different parameter scales. This includes lightweight versions optimized for edge-device deployment and high-frequency inference, as well as decoupling the architecture into distinct “Instruction” (fast execution) and “Thinking” (slow reasoning) versions to balance response speed with reasoning depth.   
• Self-Evolving Data Engine: We intend to establish a closed-loop data engine where RoboBrain 2.5 acts as a verifier for its own data. By utilizing the dense value estimator to automatically filter and annotate large-scale uncurated videos, the model can iteratively improve itself through self-supervised learning, creating a flywheel effect for continuous capability enhancement.

# References

[1] Abbas Abdolmaleki, Saminda Abeyruwan, Joshua Ainslie, Jean-Baptiste Alayrac, Montserrat Gonzalez Arenas, Ashwin Balakrishna, Nathan Batchelor, Alex Bewley, Jeff Bingham, Michael Bloesch, et al. Gemini robotics 1.5: Pushing the frontier of generalist robots with advanced embodied reasoning, thinking, and motion transfer. arXiv preprint arXiv:2510.03342, 2025.   
[2] Michael Ahn, Debidatta Dwibedi, Chelsea Finn, Montse Gonzalez Arenas, Keerthana Gopalakrishnan, Karol Hausman, Brian Ichter, Alex Irpan, Nikhil Joshi, Ryan Julian, et al. Autort: Embodied foundation models for large scale orchestration of robotic agents. arXiv preprint arXiv:2401.12963, 2024.   
[3] Minttu Alakuijala, Reginald McLean, Isaac Woungang, Nariman Farsad, Samuel Kaski, Pekka Marttinen, and Kai Yuan. Video-language critic: Transferable reward functions for language-conditioned robotics. arXiv preprint arXiv:2405.19988, 2024.   
[4] Thomas Breuel Alex Aizman, Gavin Maltby. Webdataset: High-performance data loading for deep learning, 2020. URL https://webdataset.github.io/webdataset/.   
[5] Xiang An, Yin Xie, Kaicheng Yang, Wenkang Zhang, Xiuwei Zhao, Zheng Cheng, Yirui Wang, Songcen Xu, Changrui Chen, Chunsheng Wu, et al. Llava-onevision-1.5: Fully open framework for democratized multimodal training. arXiv preprint arXiv:2509.23661, 2025.   
[6] Daichi Azuma, Taiki Miyanishi, Shuhei Kurita, and Motoaki Kawanabe. Scanqa: 3d question answering for spatial scene understanding. In CVPR, pages 19129–19139, 2022.   
[7] Alisson Azzolini, Hannah Brandon, Prithvijit Chattopadhyay, Huayu Chen, Jinju Chu, Yin Cui, Jenna Diamond, Yifan Ding, Francesco Ferroni, Rama Govindaraju, et al. Cosmos-reason1: From physical common sense to embodied reasoning. arXiv preprint arXiv:2503.15558, 2025.   
[8] Shuai Bai, Yuxuan Cai, Ruizhe Chen, Keqin Chen, Xionghui Chen, Zesen Cheng, Lianghao Deng, Wei Ding, Chang Gao, Chunjiang Ge, Wenbin Ge, Zhifang Guo, Qidong Huang, Jie Huang, Fei Huang, Binyuan Hui, Shutong Jiang, Zhaohai Li, Mingsheng Li, Mei Li, Kaixin Li, Zicheng Lin, Junyang Lin, Xuejing Liu, Jiawei Liu, Chenglong Liu, Yang Liu, Dayiheng Liu, Shixuan Liu, Dunjie Lu, Ruilin Luo, Chenxu Lv, Rui Men, Lingchen Meng, Xuancheng Ren, Xingzhang Ren, Sibo Song, Yuchong Sun, Jun Tang, Jianhong Tu, Jianqiang Wan, Peng Wang, Pengfei Wang, Qiuyue Wang, Yuxuan Wang, Tianbao Xie, Yiheng Xu, Haiyang Xu, Jin Xu, Zhibo Yang, Mingkun Yang, Jianxin Yang, An Yang, Bowen Yu, Fei Zhang, Hang Zhang, Xi Zhang, Bo Zheng, Humen Zhong, Jingren Zhou, Fan Zhou, Jing Zhou, Yuanzhi Zhu, and Ke Zhu. Qwen3-vl technical report, 2025. URL https://arxiv.org/abs/2511.21631.   
[9] Shuai Bai, Keqin Chen, Xuejing Liu, Jialin Wang, Wenbin Ge, Sibo Song, Kai Dang, Peng Wang, Shijie Wang, Jun Tang, et al. Qwen2. 5-vl technical report. arXiv preprint arXiv:2502.13923, 2025.   
[10] Shuanghao Bai, Wenxuan Song, Jiayi Chen, Yuheng Ji, Zhide Zhong, Jin Yang, Han Zhao, Wanqi Zhou, Zhe Li, Pengxiang Ding, et al. Embodied robot manipulation in the era of foundation models: Planning and learning perspectives. arXiv preprint arXiv:2512.22983, 2025.   
[11] Shuanghao Bai, Wenxuan Song, Jiayi Chen, Yuheng Ji, Zhide Zhong, Jin Yang, Han Zhao, Wanqi Zhou, Wei Zhao, Zhe Li, et al. Towards a unified understanding of robot manipulation: A comprehensive survey. arXiv preprint arXiv:2510.10903, 2025.   
[12] Qingwen Bu, Jisong Cai, Li Chen, Xiuqi Cui, Yan Ding, Siyuan Feng, Shenyuan Gao, Xindong He, Xu Huang, Shu Jiang, et al. Agibot world colosseo: A large-scale manipulation platform for scalable and intelligent embodied systems. arXiv preprint arXiv:2503.06669, 2025.   
[13] Boyuan Chen, Zhuo Xu, Sean Kirmani, Brain Ichter, Dorsa Sadigh, Leonidas Guibas, and Fei Xia. Spatialvlm: Endowing vision-language models with spatial reasoning capabilities. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 14455–14465, 2024.   
[14] Pingyi Chen, Yujing Lou, Shen Cao, Jinhui Guo, Lubin Fan, Yue Wu, Lin Yang, Lizhuang Ma, and Jieping Ye. Sd-vlm: Spatial measuring and understanding with depth-encoded vision-language models. arXiv preprint arXiv:2509.17664, 2025.   
[15] Qianzhong Chen, Justin Yu, Mac Schwager, Pieter Abbeel, Fred Shentu, and Philipp Wu. Sarm: Stage-aware reward modeling for long horizon robot manipulation. arXiv preprint arXiv:2509.25358, 2025.   
[16] Sixiang Chen, Jiaming Liu, Siyuan Qian, Han Jiang, Lily Li, Renrui Zhang, Zhuoyang Liu, Chenyang Gu, Chengkai Hou, Pengwei Wang, et al. Ac-dit: Adaptive coordination diffusion transformer for mobile manipulation. arXiv preprint arXiv:2507.01961, 2025.   
[17] Tianxing Chen, Zanxin Chen, Baijun Chen, Zijian Cai, Yibin Liu, Zixuan Li, Qiwei Liang, Xianliang Lin, Yiheng Ge, Zhenyu Gu, et al. Robotwin 2.0: A scalable data generator and benchmark with strong domain randomization for robust bimanual robotic manipulation. arXiv preprint arXiv:2506.18088, 2025.   
[18] Yi Chen, Yuying Ge, Yixiao Ge, Mingyu Ding, Bohao Li, Rui Wang, Ruifeng Xu, Ying Shan, and Xihui Liu. Egoplan-bench: Benchmarking multimodal large language models for human-level planning, 2024. URL https://arxiv.org/abs/2312.06722.   
[19] AgiBot World Colosseum contributors. Agibot world colosseum. https://github.com/OpenDriveLab/ AgiBot-World, 2024.   
[20] FlagScale Contributors. Flagscale: A unified meta-framework enabling adaptive heterogeneous computing for the llm ecosystem. https://github.com/FlagOpen/FlagScale, 2024. Accessed: 2025-06-26.   
[21] Angela Dai, Angel X Chang, Manolis Savva, Maciej Halber, Thomas Funkhouser, and Matthias Nießner. Scannet: Richly-annotated 3d reconstructions of indoor scenes. In CVPR, 2017.   
[22] Matt Deitke, Christopher Clark, Sangho Lee, Rohun Tripathi, Yue Yang, Jae Sung Park, Mohammadreza Salehi, Niklas Muennighoff, Kyle Lo, Luca Soldaini, et al. Molmo and pixmo: Open weights and open data for state-of-the-art multimodal models. arXiv preprint arXiv:2409.17146, 2024.   
[23] Matt Deitke, Christopher Clark, Sangho Lee, Rohun Tripathi, Yue Yang, Jae Sung Park, Mohammadreza Salehi, Niklas Muennighoff, Kyle Lo, Luca Soldaini, et al. Molmo and pixmo: Open weights and open data for stateof-the-art vision-language models. In Proceedings of the Computer Vision and Pattern Recognition Conference, pages 91–104, 2025.   
[24] Mengfei Du, Binhao Wu, Zejun Li, Xuan-Jing Huang, and Zhongyu Wei. Embspatial-bench: Benchmarking spatial understanding for embodied tasks with large vision-language models. In ACL, 2024.   
[25] FlagOpen. Robobrain-x0. https://github.com/FlagOpen/RoboBrain-X0, 2025. GitHub repository, accessed 2025-11-08.   
[26] Google. Gemini 3 pro: the frontier of vision ai. https://blog.google/innovation-and-ai/technology/ developers-tools/gemini-3-pro-vision/, 2025. Accessed: 2025-05-06.   
[27] Agrim Gupta, Piotr Dollar, and Ross Girshick. Lvis: A dataset for large vocabulary instance segmentation. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 5356–5364, 2019.   
[28] Xiaoshuai Hao, Lei Zhou, Zhijian Huang, Zhiwen Hou, Yingbo Tang, Lingfeng Zhang, Guang Li, Zheng Lu, Shuhuai Ren, Xianhui Meng, et al. Mimo-embodied: X-embodied foundation model technical report. arXiv preprint arXiv:2511.16518, 2025.   
[29] Zheqi He, Yesheng Liu, Jing shu Zheng, Xuejing Li, Jin-Ge Yao, Bowen Qin, Richeng Xuan, and Xi Yang. Flagevalmm: A flexible framework for comprehensive multimodal model evaluation. 2025. URL https://arxiv. org/abs/2506.09081.   
[30] Ryan Hoque, Peide Huang, David J Yoon, Mouli Sivapurapu, and Jian Zhang. Egodex: Learning dexterous manipulation from large-scale egocentric video. arXiv preprint arXiv:2505.11709, 2025.   
[31] Aaron Hurst, Adam Lerer, Adam P Goucher, Adam Perelman, Aditya Ramesh, Aidan Clark, AJ Ostrow, Akila Welihinda, Alan Hayes, Alec Radford, et al. Gpt-4o system card. arXiv preprint arXiv:2410.21276, 2024.   
[32] Physical Intelligence, Kevin Black, Noah Brown, James Darpinian, Karan Dhabalia, Danny Driess, Adnan Esmail, Michael Equi, Chelsea Finn, Niccolo Fusai, et al. pi0.5: a vision-language-action model with open-world generalization. arXiv preprint arXiv:2504.16054, 2025.   
[33] Yuheng Ji, Huajie Tan, Jiayu Shi, Xiaoshuai Hao, Yuan Zhang, Hengyuan Zhang, Pengwei Wang, Mengdi Zhao, Yao Mu, Pengju An, et al. Robobrain: A unified brain model for robotic manipulation from abstract to concrete. In Proceedings of the Computer Vision and Pattern Recognition Conference, pages 1724–1734, 2025.   
[34] Yuheng Ji, Yipu Wang, Yuyang Liu, Xiaoshuai Hao, Yue Liu, Yuting Zhao, Huaihai Lyu, and Xiaolong Zheng. Visualtrans: A benchmark for real-world visual transformation reasoning. arXiv preprint arXiv:2508.04043, 2025.   
[35] Tao Jiang, Tianyuan Yuan, Yicheng Liu, Chenhao Lu, Jianning Cui, Xiao Liu, Shuiqi Cheng, Jiyang Gao, Huazhe Xu, and Hang Zhao. Galaxea open-world dataset and g0 dual-system vla model. arXiv preprint arXiv:2509.00576, 2025.   
[36] Alexander Khazatsky, Karl Pertsch, Suraj Nair, Ashwin Balakrishna, Sudeep Dasari, Siddharth Karamcheti, Soroush Nasiriany, Mohan Kumar Srirama, Lawrence Yunliang Chen, Kirsty Ellis, et al. Droid: A large-scale in-the-wild robot manipulation dataset. arXiv preprint arXiv:2403.12945, 2024.   
[37] Eric Kolve, Roozbeh Mottaghi, Winson Han, Eli VanderBilt, Luca Weihs, Alvaro Herrasti, Matt Deitke, Kiana Ehsani, Daniel Gordon, Yuke Zhu, et al. Ai2-thor: An interactive 3d environment for visual ai. arXiv preprint arXiv:1712.05474, 2017.   
[38] Alina Kuznetsova, Hassan Rom, Neil Alldrin, Jasper Uijlings, Ivan Krasin, Jordi Pont-Tuset, Shahab Kamali, Stefan Popov, Matteo Malloci, Alexander Kolesnikov, et al. The open images dataset v4: Unified image classification, object detection, and visual relationship detection at scale. IJCV, 2020.   
[39] Justin Lazarow, David Griffiths, Gefen Kohavi, Francisco Crespo, and Afshin Dehghan. Cubify anything: Scaling indoor 3d object detection. arXiv preprint arXiv:2412.04458, 2024.   
[40] Xuechen Li, Yifan Mai, Percy Liang, and Matei Zaharia. Energon: Scaling megatron-lm training with data and expert parallelism, 2023. URL https://github.com/HazyResearch/megatron-energon.   
[41] Zhe Li, Weihao Yuan, Yisheng He, Lingteng Qiu, Shenhao Zhu, Xiaodong Gu, Weichao Shen, Yuan Dong, Zilong Dong, and Laurence T Yang. Lamp: Language-motion pretraining for motion generation, retrieval, and captioning. arXiv preprint arXiv:2410.07093, 2024.   
[42] Zhe Li, Cheng Chi, Yangyang Wei, Boan Zhu, Tao Huang, Zhenguo Sun, Yibo Peng, Pengwei Wang, Zhongyuan Wang, Fangzhou Liu, et al. Robomirror: Understand before you imitate for video to humanoid locomotion. arXiv preprint arXiv:2512.23649, 2025.   
[43] Zhe Li, Cheng Chi, Yangyang Wei, Boan Zhu, Tao Huang, Zhenguo Sun, Yibo Peng, Pengwei Wang, Zhongyuan Wang, Fangzhou Liu, et al. Do you have freestyle? expressive humanoid locomotion via audio control. arXiv preprint arXiv:2512.23650, 2025.   
[44] Zhe Li, Cheng Chi, Yangyang Wei, Boan Zhu, Yibo Peng, Tao Huang, Pengwei Wang, Zhongyuan Wang, Shanghang Zhang, and Chang Xu. From language to locomotion: Retargeting-free humanoid control via motion latent guidance. arXiv preprint arXiv:2510.14952, 2025.   
[45] Yuan-Hong Liao, Rafid Mahmood, Sanja Fidler, and David Acuna. Reasoning paths with reference objects elicit quantitative spatial reasoning in large vision-language models. arXiv preprint arXiv:2409.09788, 2024.   
[46] Aixin Liu, Bei Feng, Bing Xue, Bingxuan Wang, Bochao Wu, Chengda Lu, Chenggang Zhao, Chengqi Deng, Chenyu Zhang, Chong Ruan, et al. Deepseek-v3 technical report. arXiv preprint arXiv:2412.19437, 2024.   
[47] Bo Liu, Yifeng Zhu, Chongkai Gao, Yihao Feng, Qiang Liu, Yuke Zhu, and Peter Stone. Libero: Benchmarking knowledge transfer for lifelong robot learning. Advances in Neural Information Processing Systems, 36:44776– 44791, 2023.   
[48] Haotian Liu, Chunyuan Li, Yuheng Li, and Yong Jae Lee. Improved baselines with visual instruction tuning. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 26296–26306, 2024.   
[49] Shilong Liu, Zhaoyang Zeng, Tianhe Ren, Feng Li, Hao Zhang, Jie Yang, Qing Jiang, Chunyuan Li, Jianwei Yang, Hang Su, et al. Grounding dino: Marrying dino with grounded pre-training for open-set object detection. In ECCV, 2024.   
[50] Ruiyuan Lyu, Tai Wang, Jingli Lin, Shuai Yang, Xiaohan Mao, Yilun Chen, Runsen Xu, Haifeng Huang, Chenming Zhu, Dahua Lin, and Jiangmiao Pang. Mmscan: A multi-modal 3d scene dataset with hierarchical grounded language annotations. arXiv preprint arXiv:2406.09401, 2024.   
[51] Xiaojian Ma, Silong Yong, Zilong Zheng, Qing Li, Yitao Liang, Song-Chun Zhu, and Siyuan Huang. Sqa3d: Situated question answering in 3d scenes. In ICLR, 2023. URL https://openreview.net/forum?id=IDJx97BC38.   
[52] Yecheng Jason Ma, Vikash Kumar, Amy Zhang, Osbert Bastani, and Dinesh Jayaraman. Liv: Languageimage representations and rewards for robotic control. In International Conference on Machine Learning, pages 23301–23320. PMLR, 2023.   
[53] Yecheng Jason Ma, William Liang, Guanzhi Wang, De-An Huang, Osbert Bastani, Dinesh Jayaraman, Yuke Zhu, Linxi Fan, and Anima Anandkumar. Eureka: Human-level reward design via coding large language models. arXiv preprint arXiv:2310.12931, 2023.   
[54] Yecheng Jason Ma, Joey Hejna, Chuyuan Fu, Dhruv Shah, Jacky Liang, Zhuo Xu, Sean Kirmani, Peng Xu, Danny Driess, Ted Xiao, et al. Vision language models are in-context value learners. In The Thirteenth International Conference on Learning Representations, 2024.   
[55] Soroush Nasiriany, Abhiram Maddukuri, Lance Zhang, Adeet Parikh, Aaron Lo, Abhishek Joshi, Ajay Mandlekar, and Yuke Zhu. Robocasa: Large-scale simulation of everyday tasks for generalist robots. arXiv preprint arXiv:2406.02523, 2024.   
[56] NVIDIA. Megatron-lm: Training multi-billion parameter language models using model parallelism, 2021. URL https://github.com/NVIDIA/Megatron-LM.   
[57] OpenAI. Update to gpt-5 system card: Gpt-5.2. https://openai.com/zh-Hans-CN/index/ gpt-5-system-card-update-gpt-5-2/, 2025. Accessed: 2025-05-06.   
[58] Kun Ouyang. Spatial-r1: Enhancing mllms in video spatial reasoning. arXiv preprint arXiv:2504.01805, 2025.   
[59] Abby O’Neill, Abdul Rehman, Abhiram Maddukuri, Abhishek Gupta, Abhishek Padalkar, Abraham Lee, Acorn Pooley, Agrim Gupta, Ajay Mandlekar, Ajinkya Jain, et al. Open x-embodiment: Robotic learning datasets and rt-x models: Open x-embodiment collaboration 0. In 2024 IEEE International Conference on Robotics and Automation (ICRA), pages 6892–6903. IEEE, 2024.   
[60] Luigi Piccinelli, Christos Sakaridis, Yung-Hsu Yang, Mattia Segu, Siyuan Li, Wim Abbeloos, and Luc Van Gool. Unidepthv2: Universal monocular metric depth estimation made simpler. arXiv, 2025.   
[61] PyTorch Developers. Cuda memory management, 2023. URL https://pytorch.org/docs/stable/notes/cuda. html#cuda-memory-management.   
[62] Qwen Team. Qwen2.5-vl: Multimodal llms from alibaba, 2025. URL https://github.com/QwenLM/Qwen2.5-VL.   
[63] Vignesh Ramanathan, Anmol Kalia, Vladan Petrovic, Yi Wen, Baixue Zheng, Baishan Guo, Rui Wang, Aaron Marquez, Rama Kovvuri, Abhishek Kadian, et al. Paco: Parts and attributes of common objects. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 7141–7151, 2023.   
[64] Nikhila Ravi, Valentin Gabeur, Yuan-Ting Hu, Ronghang Hu, Chaitanya Ryali, Tengyu Ma, Haitham Khedr, Roman Rädle, Chloe Rolland, Laura Gustafson, et al. Sam 2: Segment anything in images and videos. ICLR, 2025.   
[65] Pierre Sermanet, Tianli Ding, Jeffrey Zhao, Fei Xia, Debidatta Dwibedi, Keerthana Gopalakrishnan, Christine Chan, Gabriel Dulac-Arnold, Sharath Maddineni, Nikhil J Joshi, et al. Robovqa: Multimodal long-horizon reasoning for robotics. In 2024 IEEE International Conference on Robotics and Automation (ICRA), pages 645–652. IEEE, 2024.   
[66] Chan Hee Song, Valts Blukis, Jonathan Tremblay, Stephen Tyree, Yu Su, and Stan Birchfield. Robospatial: Teaching spatial understanding to 2d and 3d vision-language models for robotics. In Proceedings of the Computer Vision and Pattern Recognition Conference, pages 15768–15780, 2025.   
[67] Huajie Tan, Sixiang Chen, Yijie Xu, Zixiao Wang, Yuheng Ji, Cheng Chi, Yaoxu Lyu, Zhongxia Zhao, Xiansheng Chen, Peterson Co, et al. Robo-dopamine: General process reward modeling for high-precision robotic manipulation. arXiv preprint arXiv:2512.23703, 2025.   
[68] Huajie Tan, Cheng Chi, Xiansheng Chen, Yuheng Ji, Zhongxia Zhao, Xiaoshuai Hao, Yaoxu Lyu, Mingyu Cao, Junkai Zhao, Huaihai Lyu, et al. Roboos-next: A unified memory-based framework for lifelong, scalable, and robust multi-robot collaboration. arXiv preprint arXiv:2510.26536, 2025.   
[69] Huajie Tan, Xiaoshuai Hao, Minglan Lin, Pengwei Wang, Yaoxu Lyu, Mingyu Cao, Zhongyuan Wang, and Shanghang Zhang. Roboos: A hierarchical embodied framework for cross-embodiment and multi-agent collaboration. arXiv preprint arXiv:2505.03673, 2025.   
[70] Huajie Tan, Yuheng Ji, Xiaoshuai Hao, Xiansheng Chen, Pengwei Wang, Zhongyuan Wang, and Shanghang Zhang. Reason-rft: Reinforcement fine-tuning for visual reasoning of vision language models. In The Thirty-ninth Annual Conference on Neural Information Processing Systems, 2025.   
[71] Huajie Tan, Peterson Co, Yijie Xu, Shanyu Rong, Yuheng Ji, Cheng Chi, Xiansheng Chen, Qiongyu Zhang, Zhongxia Zhao, Pengwei Wang, et al. Action-sketcher: From reasoning to action via visual sketches for long-horizon robotic manipulation. arXiv preprint arXiv:2601.01618, 2026.   
[72] BAAI RoboBrain Team, Mingyu Cao, Huajie Tan, Yuheng Ji, Xiansheng Chen, Minglan Lin, Zhiyu Li, Zhou Cao, Pengwei Wang, Enshen Zhou, et al. Robobrain 2.0 technical report. arXiv preprint arXiv:2507.02029, 2025.   
[73] Gemini Robotics Team, Saminda Abeyruwan, Joshua Ainslie, Jean-Baptiste Alayrac, Montserrat Gonzalez Arenas, Travis Armstrong, Ashwin Balakrishna, Robert Baruch, Maria Bauza, Michiel Blokzijl, et al. Gemini robotics: Bringing ai into the physical world. arXiv preprint arXiv:2503.20020, 2025.   
[74] Qwen Team. Qwq-32b: Embracing the power of reinforcement learning, March 2025. URL https://qwenlm. github.io/blog/qwq-32b/.   
[75] Peter Tong, Ellis Brown, Penghao Wu, Sanghyun Woo, Adithya Jairam Vedagiri IYER, Sai Charitha Akula, Shusheng Yang, Jihan Yang, Manoj Middepogu, Ziteng Wang, et al. Cambrian-1: A fully open, vision-centric exploration of multimodal llms. NeurIPS, 2024.   
[76] Johanna Wald, Armen Avetisyan, Nassir Navab, Federico Tombari, and Matthias Nießner. Rio: 3d object instance re-localization in changing indoor environments. In ICCV, pages 7658–7667, 2019.   
[77] Yipu Wang, Yuheng Ji, Yuyang Liu, Enshen Zhou, Ziqiang Yang, Yuxuan Tian, Ziheng Qin, Yue Liu, Huajie Tan, Cheng Chi, et al. Towards cross-view point correspondence in vision-language models. arXiv preprint arXiv:2512.04686, 2025.   
[78] Wentao Yuan, Jiafei Duan, Valts Blukis, Wilbert Pumacay, Ranjay Krishna, Adithyavairavan Murali, Arsalan Mousavian, and Dieter Fox. Robopoint: A vision-language model for spatial affordance prediction for robotics, 2024. URL https://arxiv.org/abs/2406.10721.   
[79] Yifu Yuan, Haiqin Cui, Yaoting Huang, Yibin Chen, Fei Ni, Zibin Dong, Pengyi Li, Yan Zheng, and Jianye Hao. Embodied-r1: Reinforced embodied reasoning for general robotic manipulation. arXiv preprint arXiv:2508.13998, 2025.   
[80] Shaopeng Zhai, Qi Zhang, Tianyi Zhang, Fuxian Huang, Haoran Zhang, Ming Zhou, Shengzhe Zhang, Litao Liu, Sixu Lin, and Jiangmiao Pang. A vision-language-action-critic model for robotic real-world reinforcement learning. arXiv preprint arXiv:2509.15937, 2025.   
[81] Wenqi Zhang, Mengna Wang, Gangao Liu, Xu Huixin, Yiwei Jiang, Yongliang Shen, Guiyang Hou, Zhe Zheng, Hang Zhang, Xin Li, et al. Embodied-reasoner: Synergizing visual search, reasoning, and action for embodied interactive tasks. arXiv preprint arXiv:2503.21696, 2025.   
[82] Yi Zhang, Bolin Ni, Xin-Sheng Chen, Heng-Rui Zhang, Yongming Rao, Houwen Peng, Qinglin Lu, Han Hu, Meng-Hao Guo, and Shi-Min Hu. Bee: A high-quality corpus and full-stack suite to unlock advanced fully open mllms, 2025. URL https://arxiv.org/abs/2510.13795.   
[83] Youcai Zhang, Xinyu Huang, Jinyu Ma, Zhaoyang Li, Zhaochuan Luo, Yanchun Xie, Yuzhuo Qin, Tong Luo, Yaqian Li, Shilong Liu, et al. Recognize anything: A strong image tagging model. In CVPR, 2024.   
[84] Enshen Zhou, Qi Su, Cheng Chi, Zhizheng Zhang, Zhongyuan Wang, Tiejun Huang, Lu Sheng, and He Wang. Code-as-monitor: Constraint-aware visual programming for reactive and proactive robotic failure detection. arXiv preprint arXiv:2412.04455, 2024.   
[85] Enshen Zhou, Jingkun An, Cheng Chi, Yi Han, Shanyu Rong, Chi Zhang, Pengwei Wang, Zhongyuan Wang, Tiejun Huang, Lu Sheng, et al. Roborefer: Towards spatial referring with reasoning in vision-language models for robotics. arXiv preprint arXiv:2506.04308, 2025.   
[86] Enshen Zhou, Cheng Chi, Yibo Li, Jingkun An, Jiayuan Zhang, Shanyu Rong, Yi Han, Yuheng Ji, Mengzhen Liu, Pengwei Wang, et al. Robotracer: Mastering spatial trace with reasoning in vision-language models for robotics. arXiv preprint arXiv:2512.13660, 2025.   
[87] Shengjie Zhu, Abhinav Kumar, Masa Hu, and Xiaoming Liu. Tame a wild camera: in-the-wild monocular camera calibration. NIPS, 2023.

# Core Contributors

• Huajie Tan∗†   
• Enshen Zhou∗   
• Zhiyu Li   
• Yijie Xu   
• Yuheng Ji   
• Xiansheng Chen   
• Cheng Chi   
• Pengwei Wang†   
• Huizhu Jia   
• Yulong Ao   
• Yonghua Lin   
• Zhongyuan Wang   
• Tiejun Huang   
• Shanghang Zhang $\mathbb { P } \triangleleft$

# Contributors

• Mingyu Cao   
• Sixiang Chen   
• Zhe Li   
• Mengzhen Liu • Zixiao Wang   
• Shanyu Rong • Yaoxu Lyu   
• Zhongxia Zhao • Peterson Co   
• Yibo Li   
• Yi Han   
• Shaoxuan Xie • Guocai Yao   
• Songjing Wang • Leiduo Zhang • Xi Yang   
• Yance Jiao   
• Donghai Shi   
• Kunchang Xie • Shaokai Nie   
• Chunlei Men

# Appendix

# A Qualitative examples

This section provides a comprehensive set of qualitative examples that illustrate the capabilities of RoboBrain 2.5 in various embodied AI tasks. As Capabilities like pointing, affordance, planning, etc. are similar to those shown in RoboBrain 2.0 [72], the examples in this section ONLY demonstrate the model’s proficiency in 3D spatial reasoning, temporal value estimation, showcasing its potential for real-world applications.

# A.1 Examples on 3D Spatial Reasoning

In this section, we provide qualitative visualizations to demonstrate the robustness and precision of RoboBrain 2.5’s 3D spatial reasoning capabilities in real-world manipulation scenarios. We focus on three core aspects: compliance with fine-grained spatial constraints, multi-step compositional reasoning for complex manipulation tasks, and generalization across diverse indoor environments and object categories.

Compliance with Fine-Grained Spatial Constraints. RoboBrain 2.5 excels at interpreting spatially constrained instructions and generating accurate 3D manipulation traces that adhere to both relative positional requirements and metric constraints. For instructions like “Pick up the third picture frame from the left on the piano, and move it to the right of the biggest wooden chair” in Figure 3 or “Pick up the rightmost vase on the desk, and move it to the spot between the black monitor and the water bottle” in Figure 4, the model accurately parses ordinal references and spatial relationships to generate collision-free 3D trajectories.

Multi-Step Compositional Reasoning. Complex manipulation tasks often demand multi-step reasoning to decompose high-level goals into executable sub-tasks. RoboBrain 2.5’s 3D spatial tracing capability naturally encodes this compositional logic by generating ordered keypoint sequences. For example, instructions like “Pick up the orange object at right which is on the window sill, and move it to a spot which is on the sink’s edge and closest to the right wall” require the model to firstly localize the orange object on the window sill, then estimate the sink’s edge position and its distance to the right wall, and finally generate a smooth 3D trace connecting the two points while avoiding obstacles.

Generalization Across Environments and Objects. RoboBrain 2.5’s 3D spatial reasoning generalizes to diverse indoor settings and object categories. Tasks span kitchen-centric scenarios in Figure 4, bedroom settings in Figure 5, and office/study spaces. The model maintains precision across these environments by leveraging metric-grounded spatial representations independent of scene context. Besides, the model handles objects of varying sizes, shapes, and functionalities, which are from small items to larger objects, and adapts its 3D traces to object-specific affordances.

Application on RoboTwin 2.0 To further validate the generalization capabilities of RoboBrain 2.5 in simulated collaborative environments, we present qualitative results on the RoboTwin 2.0 [17], specifically focusing on AgiLex dual-arm manipulation tasks. As illustrated in Figure 6 - Figure 9, the model demonstrates robust performance in generating precise 3D spatial traces from complex natural language instructions. For example, Figure 6 highlights the model’s fine-grained spatial discrimination and reasoning abilities. In tasks such as Click Bell, Click Alarmclock, and Blocks Ranking, RoboBrain 2.5 accurately identifies specific targets based on relative spatial descriptions (e.g., “closest to milk box”, “to the left of globe”) and comparative attributes (e.g., “second largest”, “farthest from the camera”). The generated traces correctly guide the agent to the intended objects among multiple distractors. Figure 7 showcases the model’s proficiency in dual-arm coordination and object manipulation. In scenarios like Handover Block, Handover Mic, Hanging Mug, and Move Can Pot, the model predicts coherent spatial traces that effectively handle arm-specific instructions (e.g., “with the right arm”) and precise placement goals (e.g., “hang it onto the rack”). These examples confirm that RoboBrain 2.5 can successfully ground high-level semantic instructions into collision-free, metric-aware trajectories for high-DoF robotic systems.

These examples collectively demonstrate that RoboBrain 2.5’s precise 3D spatial reasoning capability effectively bridges the gap between natural language instructions and physical execution, enabling precise, constraintcompliant manipulation in real-world settings.

![](images/3be0c84268e9f674948b79aca955c9d3ba77f02cd97a07ea6986e2f78690797b.jpg)  
Reasoning Step = 4 Pick up the sponge wipe in the white cup, and move it into the sink.

![](images/b070ffe31754103e4bd2c3b1fb1d70562df5cb8dcd345f077fc051b4f84498e5.jpg)  
Reasoning Step $= 4$

Pick up the towel hanging on the handle of the oven, and move it into the sink.

![](images/06b19e09bfe64bce36fc302c480f188d8c91f1942584290db9b1cc982906534c.jpg)  
Reasoning $S t e p = 4$

Pick up the brown small bottle on the table, and move it to the left of the white mouse.

![](images/6b7d4bb26e2645fb3b3e3c76f866beb67d6cf76282e8dc12c6b364103fd5d0d2.jpg)  
Reasoning $S t e p = 6$

Pick up the orange object at right which is on the window sill, and move it to a spot which is on the sink's edge and closest to the right wall

![](images/cf450369b0d414da356df1d457dae1167d1ec923e562996af39d1884fa966247.jpg)  
Reasoning $S t e p = 6$

Pick up the gray toy on the shelf, and move it to the spot which is on the left white table and near the left side of the white shelf.

![](images/fc98d5da2748b8830218456c8293d473c8de37c337e33cb6b4b6784156f6e11d.jpg)  
Reasoning Step $= 6$

Pick up the second black remote controller from the front on the table, and move it to the spot which is on the bed and on the left of the closest pillow.

Reasoning $S t e p = 3$ Pick up the bule bag, and move it to the left of the yellow towel.

![](images/b714f08e0ec3287f5675a1b8a8be2a5b4a53273e3a9e22268a06520a4b6be19a.jpg)

Pick up the third picture frame from the left on the piano, and move it to the right of the biggest wooden chair.

![](images/f2d396f6d134362580d038a5f3e995b21cf4d7f9b51dbff15b0ff98f16b171a4.jpg)  
Figure 3 Visualization of TraceSpatial-Bench Rollouts and RoboBrain 2.5’s Predicted Traces. The red mask marks the ground-truth starting point, the purple 3D bounding box represents the ground-truth endpoint, and the 2D projection of RoboBrain 2.5’s predicted 3D spatial trace is displayed.

![](images/6b46f8f8fd3f931f36e7939183961afd3acb6d8a089cdc82635dc2500b5b9bdf.jpg)

# Reasoning Step = 6

Pick up the white box on the table, and move it to the spot which is on the window sill and between the red card and vase.

![](images/05c53ddd0d3b301fa604a43a18753374b4173ad831464a9f4c13013b9a8cae65.jpg)  
Reasoning $S t e p = 4$

Pick up the dark blue clothes which is hanging on the clothes rack, and move it to the white basket on the right.

![](images/3ca57d39d1e76461ebed194a194a2a6eefee7eaa23665282094c1a1e4eba074b.jpg)  
Reasoning $S t e p = 6$

Pick up the rightmost vase on the desk, and move it to the spot between the black monitor and the water bottle.

![](images/308215aaba953c9bd60e0428eaaf60590eeef519d9c53a361fd0e1510aeb6378.jpg)  
Reasoning $S t e p = 7$

Pick up the colorful card on the right table, and move it to the right of the dark blue clothes which is on the left wooden table.

![](images/2bf0801e689e718cdc608f3881bb055167b2e065a0f596e9723bb241d5c566e0.jpg)  
Reasoning $S t e p = 6$

Pick up the white closest clothes, and move it to the spot in the sink and in front of the yellow bottle.

![](images/ad60ea47da0eded32551c4ea22b855714ad2445b4092343e49d819a1b02b0b16.jpg)  
Reasoning Step = 6

Pick up the dark blue cup which is the closest cup to the keyboard, and move it to the spot which is in front of the stapler on the left.

![](images/754fbd00ce8735ac25f350cc911096c63485fea6deb98114fe15af06dff5a2f1.jpg)  
Reasoning $S t e p = 3$

Pick up the toothpaste, and move it to the top of the stack of books.

![](images/6bcbe528054f7f53dc729c3669fbcd060bffa2a796aadb9842acc0baa9bfbe30.jpg)

![](images/97af2e5f03ef136262328f3c306292094b5761bf3f229abea408fc5f3b6457a5.jpg)

# Reasoning $S t e p = 5$

Pick up the blue clock on the wooden stand, and move it to the front of the pillow which is the first pillow from the left.

# Reasoning $S t e p = 6$

![](images/57f8808e3423b0da2c888a9a38fa667ba9b219635343b20b1c77c6d0bdbf1140.jpg)  
Figure 4 Visualization of TraceSpatial-Bench Rollouts and RoboBrain 2.5’s Predicted Traces. The red mask marks the ground-truth starting point, the purple 3D bounding box represents the ground-truth endpoint, and the 2D projection of RoboBrain 2.5’s predicted 3D spatial trace is displayed.

Pick up the red object which is on the rightmost table, and move it to the spot which is on the center cabinet and in front of the black object.

Reasoning $S t e p = 5$ Pick up the napkin in the box on the left, and move it to the right of round porcelain.

![](images/ac89c783c9297cb2dff50dd52e26337ebbc74f606d3fbe61843c8f5975193c48.jpg)  
Reasoning Step = 2

Pick up the brown towel, and move it to the metal sink.

![](images/4bc7a73a71518a010b611f0575ad55956b0cb17de5dfb9895ee5dffac5c581a3.jpg)  
Reasoning Step = 3

Pick up the toothpaste on the table, and move it to the blue waste bin next to the table.

![](images/5adc3f23011e7ab4ff7205dcaca1e4070a107d456e0ff878f275337918de7cc5.jpg)  
Reasoning $S t e p = 3$

Pick up the paper cup on the table, and move it to the waste bin.

![](images/6e019afe274b9f26b2a8fe998384600be96248fc7b1401e8b0bd7306c0c511e1.jpg)

# Reasoning $S t e p = 7$

Pick up the white cup on the left wooden table, and move it to the spot on the top of the white shelf and between the stack of paper and calendar.

![](images/756c7dbd57be34a8610c6fb3e09fe23abc16a6b1f7716c7fd3a052a84878726a.jpg)  
Reasoning $S t e p = 5$

Pick up the glass cup, and move it to the spot which is between the closest monitor and keyboard.

![](images/2af17d5a5087b6af5d1f2284e88d5e85e2ce3cff9ba806556a028fed851d280e.jpg)  
Reasoning Step = 6

Pick up the green paper box on the stand next to the bed, and move it to the right of the pillow.

![](images/5a42e0630382ccef4cf8d38ead688974d30742f2b532092115cac46210bef2fe.jpg)

![](images/d957e6a0c42511f8f68f85dcf334e2eb865d786e78539ce49f54c4d0ff805b34.jpg)

# Reasoning $S t e p = 7$

Pick up the black controller which is the second black object on the stand from the left, and move it to the white plate on the right side of the lamp.

# Reasoning Step = 7

![](images/581cee7541ba3a9da24be935c846453d8dd6f99dbe73413da0ee155862ddb4bd.jpg)  
Figure 5 Visualization of TraceSpatial-Bench Rollouts and RoboBrain 2.5’s Predicted Traces. The red mask marks the ground-truth starting point, the purple 3D bounding box represents the ground-truth endpoint, and the 2D projection of RoboBrain 2.5’s predicted 3D spatial trace is displayed.

Pick up the brown toy dog next to the door, and move it to the spot which is on the wooden table, between the glass jars filled with colorful candies and white remote control.

# Reasoning Step $= 6$

Pick up the picture frame which is closest to the lamp, and move it to the spot which is on the window sill and on the right side of the small picture frame.

![](images/43b1b5e7385eef573c2e27ffff5559556a7c36abe3edd081ee8014f20208faf0.jpg)  
Figure 6 Visualization of RoboTwin 2.0 Rollouts and RoboBrain 2.5’s Predicted Traces. Examples for AgiLex Dual-Arm tasks: Click Bell; Click Alarm clock; Blocks Ranking.

![](images/7972b79e6a0d3c3453a26e937a83aa7b850a0070d65c93aa97b04ea0efb725a0.jpg)  
Figure 7 Visualization of RoboTwin 2.0 Rollouts and RoboBrain 2.5’s Predicted Traces. Examples for AgiLex Dual-Arm tasks: Handover Block; Handover Mic; Hanging Mug; Move Can Pot.

![](images/317544704e9e57eb7915cb839965f493cfcafa3233d251325218ab5ab646248a.jpg)  
Figure 8 Visualization of RoboTwin 2.0 Rollouts and RoboBrain 2.5’s Predicted Traces. Examples for AgiLex Dual-Arm tasks: Move Playingcard Away; Move Stapler Pad; Open Laptop; Place A2B Left.

![](images/0704b29b58a9069b05a5f6bba155214ac45d2554a02a69af8577e165093b8cac.jpg)  
Figure 9 Visualization of RoboTwin 2.0 Rollouts and RoboBrain 2.5’s Predicted Traces. Examples for AgiLex Dual-Arm tasks: Place A2B Right; Place Bread Basket; Place Bread Skillet; Place Burger Fries.

# A.2 Examples on Temporal Value Estimation

In this section, we provide additional qualitative visualizations to further substantiate the effectiveness and robustness of our method. We focus on three key aspects: the generalization of RoboBrain 2.5 across diverse semantic tasks, the temporal robustness of progress estimation under varying sampling intervals, and the trajectory visualization of real-world RL.

Dense Value Predictions on Diverse Tasks. Figure 10 illustrates the predicted Hop and Progress curves generated by our RoboBrain 2.5 across a wide spectrum of manipulation tasks, encompassing both real-world scenarios and simulation environments. Specifically, we visualize complex tasks such as deformable object manipulation (e.g., Fold the Pants), unstructured real-world interaction (e.g., Clean the table), and precise multi-stage simulation tasks (e.g., Stack three Bowls, Open the drawer ). The results demonstrate that our model effectively generalizes across these distinct domains. In successful trajectories, the model consistently predicts positive Hop values corresponding to effective state transitions, which accumulate into a smooth, monotonic Progress curve that accurately reflects task completion. Crucially, the model is able to distinguish between effective progress and background noise, providing a stable signal even in visually cluttered real-world settings.

Robustness to Temporal Intervals. A robust reward model should remain consistent regardless of the video sampling rate or the control frequency of the robot. Figure 11 provides a comparative analysis of RoboBrain 2.5’s progress estimation when inputs are sampled at significantly different intervals ( $\Delta t = 1 0 , 2 5 , 5 0 , 1 0 0$ frames). As shown in the comparison, although the visual disparity between adjacent frames increases drastically with larger $\Delta t$ , the model adaptively predicts larger Hop values to account for the increased semantic distance. Consequently, the reconstructed global progress curves across all sampling rates exhibit high alignment and overlap. This invariance highlights the model’s ability to decouple physical progress from temporal duration, ensuring that the value estimation remains reliable whether the agent operates at high frequency or processes sparse keyframes.

Visualization of Different Progress Estimation Modes. Furthermore, to elucidate the robustness of our progress estimation, Figure 12 visualizes the three complementary perspectives used in our Multi-Perspective Progress Fusion strategy. Specifically, (a) Incremental Prediction recursively accumulates frame-wise hop values to capture fine-grained local dynamics; (b) Forward-Anchored Prediction estimates progress relative to the initial state, providing a stable baseline during early execution; and (c) Backward-Anchored Prediction measures progress against the goal state, offering high sensitivity near task completion. As demonstrated, all three modes yield consistent, monotonic progress curves on unseen validation tasks, confirming that fusing these perspectives effectively mitigates error accumulation while maintaining global consistency.

Real-World RL Rollout Visualization. Finally, Figure 13 visualizes the robustness of the policy learned for the “Insert Block” task. The policy used in this rollout was trained for approximately 20 minutes and achieved a success rate of over $9 5 \%$ . To evaluate the policy’s reactivity and the reward model’s accuracy, we introduced an artificial disturbance during execution. As shown in the sequence, a human operator manually moves the target slot while the robot is in motion (a). This intervention causes the robot to miss the target and fall into misalignment (b). Crucially, the inset plots show that RoboBrain 2.5 immediately reflects this setback: the estimated Progress drops sharply, correctly identifying that the state has regressed from the goal. This accurate negative feedback guides the agent to adjust its trajectory. The robot successfully recovers from the misalignment (c), repositions itself above the target (d), aligns with the slot (e), and completes the insertion (f). This demonstrates that RoboBrain 2.5 provides dense, semantically meaningful rewards that enable the agent to recover from unexpected external perturbations.

![](images/1d665a3f5afcf362aef6c5ab6293a4de41e475eef9f7a3f8e627267f9a5773fb.jpg)  
Figure 10 RoboBrain 2.5 Progress Predictions across Diverse Tasks. We visualize the frame-wise Hop (instantaneous change) and accumulated Progress predicted by RoboBrain 2.5 on unseen validation tasks.

![](images/c71f75a2586ddd4afb586f3302cce517caff7f9c195a33b847569d66296a7a19.jpg)  
Figure 11 Progress Estimation Consistency across Sampling Intervals. We plot the reconstructed progress curves for the same trajectory using different frame strides (10, 25, 50, and 100 frames). The high overlap between curves demonstrates that our RoboBrain 2.5 is robust to temporal granularity and does not simply overfit to a specific frame rate.

![](images/fabc7dae245a5feb06afca3838bf5e54957a9780d53afa4997ac258346fcff49.jpg)  
Figure 12 RoboBrain 2.5 Progress Predictions across three modes. We visualize the frame-wise Hop (instantaneous change) and accumulated Progress predicted by RoboBrain 2.5 with incremental, forward-anchored and backwardanchored mode.

![](images/02d175eee6567a3c483903c2618625d166e016cca4490ca61fd9818315e2c11a.jpg)  
Figure 13 Robustness to Artificial Disturbance during Real-World Execution. We visualize a rollout of the converged policy (success rate $> 9 5 \%$ ) under human interference. Each sub-figure shows the third-person view, the ego-centric view, and the real-time RoboBrain 2.5 inference (Top: Hop, Bottom: Progress). (a) Artificial Disturbance Position: A human hand intervenes and shifts the target board while the robot attempts to approach. (b) Fall Into Misalignment: The robot misses the new position. Note that the RoboBrain 2.5 Progress curve drops significantly (indicated by the red dot in the bottom inset), reflecting the failure state. (c) Misalignment Recovery: The policy reacts to the visual feedback and the drop in reward, adjusting the end-effector position. (d) Move to the top: The robot realigns directly above the target slot. (e) Align with the Slot: Precise fine-tuning before insertion. (f) Successful Insertion: The task is completed, with the progress estimation reaching its peak.

# B Proof of Bounded Global Progress

In this subsection, we provide a formal proof that iteratively applying the predicted relative progress hops guarantees that the reconstructed global progress $\Phi ^ { \star } ( s )$ remains strictly within the bounds $[ 0 , 1 ]$ , provided that the initial state is bounded and the model predictions lie within $[ - 1 , 1 ]$ .

First, we define the general recursive update rule. Based on the definition of the hop label $\mathcal { H } ( s _ { p } , s _ { q } )$ in Equation 2, we derive the recursive update rule for estimating the global progress of the next state $\Phi ^ { \star } ( s _ { t } )$ given the current state $\Phi ^ { \star } \left( s _ { t - 1 } \right)$ and the predicted hop $H = \mathcal { H } ( s _ { t - 1 } , s _ { t } )$ . We assume the normalization where $\Phi ( s _ { 0 } ) = 0$ and $\Phi ( s _ { M } ) = 1$ . Rearranging the equation, the update rule is:

$$
\Phi ^ { \star } ( s _ { t } ) = { \left\{ \begin{array} { l l } { \Phi ^ { \star } ( s _ { t - 1 } ) + H \cdot [ 1 - \Phi ^ { \star } ( s _ { t - 1 } ) ] } & { { \mathrm { i f ~ } } H \geq 0 } \\ { \Phi ^ { \star } ( s _ { t - 1 } ) + H \cdot \Phi ^ { \star } ( s _ { t - 1 } ) } & { { \mathrm { i f ~ } } H < 0 } \end{array} \right. }
$$

Given that the initial progress $\Phi ^ { \star } ( s _ { 0 } ) = 0$ and the predicted hop $H \in [ - 1 , 1 ]$ , the reconstructed global progress $\Phi ^ { \star } ( s _ { t } )$ satisfies $\Phi ^ { \star } ( s _ { t } ) \in [ 0 , 1 ]$ for all steps $t$ .

We proceed by mathematical induction as follow: (1) Base Case ( $\ell = 0$ ): By definition, $\Phi ^ { \star } ( s _ { 0 } ) = 0$ , which satisfies $0 \in \left[ 0 , 1 \right]$ . (2) Inductive Step: Assume that for step $t - 1$ , the hypothesis holds: $0 \leq \Phi ^ { \star } ( s _ { t - 1 } ) \leq 1$ . Let $G = \Phi ^ { \star } ( s _ { t - 1 } )$ for brevity, where $G \in [ 0 , 1 ]$ . We analyze the next state $\Phi ^ { \star } ( s _ { t } )$ under two cases (i.e., Positive Hop and Negative Hop) based on the sign of the predicted hop $H$ .

# • Case 1: Positive Hop (Progress), $0 \leq H \leq 1$

From Equation (12), the update is written as:

$$
\Phi ^ { \star } ( s _ { t } ) = G + H ( 1 - G )
$$

Rearranging terms to view this as a convex combination:

$$
\Phi ^ { \star } ( s _ { t } ) = H + G ( 1 - H )
$$

Lower Bound: Since $G \geq 0$ , $H \geq 0$ , and $( 1 - H ) \geq 0$ , it follows that $\Phi ^ { \star } ( s _ { t } ) \geq 0$ . Upper Bound: Since $G \leq 1$ , we substitute the maximum value of $G$ :

$$
\begin{array} { l } { \Phi ^ { \star } \bigl ( s _ { t } \bigr ) = H + G \bigl ( 1 - H \bigr ) } \\ { \qquad \leq H + 1 \cdot ( 1 - H ) } \\ { \qquad = H + 1 - H } \\ { \qquad = 1 } \end{array}
$$

Thus, $0 \leq \Phi ^ { \star } ( s _ { t } ) \leq 1$ when $H \geq 0$ .

• Case 2: Negative Hop (Regress), $- 1 \leq H < 0$

From Equation (12), the update is:

$$
\Phi ^ { \star } ( s _ { t } ) = G + H \cdot G = G ( 1 + H )
$$

Lower Bound: Since $H \in [ - 1 , 0 )$ , the term $\left( 1 + H \right) \geq 0$ . Since $G \geq 0$ , the product $G ( 1 + H ) \geq 0$ . Upper Bound: Since $H < 0$ , the term $( 1 + H ) < 1$ . Combining this with $G \leq 1$ :

$$
\Phi ^ { \star } ( s _ { t } ) = G ( 1 + H ) \leq 1 \cdot ( 1 ) = 1
$$

Thus, $0 \leq \Phi ^ { \star } ( s _ { t } ) \leq 1$ when $H < 0$ .

Conclusion. Since the property holds for the base case and is preserved in both update scenarios during the inductive step, we conclude that $\Phi ^ { \star } ( s _ { t } ) \in [ 0 , 1 ]$ for all $t$ .